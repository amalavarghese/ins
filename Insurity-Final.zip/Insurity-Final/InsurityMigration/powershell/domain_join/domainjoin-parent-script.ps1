﻿$azureAplicationId ="xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"
$azureTenantId= "xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"
$ClientSecret = "xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"

$SubID = "xxxxx-xxxxxxx-xxxxxxxxxxx"

$LocalCred_KVName = "kv-az-secrets-01"
$LocalUsername_Secret = "VM-local-admin-username"
$LocalPassword_Secret = "VM-local-admin-password"

$Domain = "jarvis.com"

$DomainCred_KVName = "kv-az-secrets-01"
$DomainUsername_Secret = "VM-domain-admin-username"
$DomainPassword_Secret = "VM-domain-admin-password"

## Login
$azurePassword = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
$psCred = New-Object System.Management.Automation.PSCredential($azureAplicationId , $azurePassword)
Add-AzAccount -Credential $psCred -TenantId $azureTenantId  -ServicePrincipal 

## Set Context to Subscription
Set-AzContext -Subscription $SubID



### Extract Local Credentials from KV
$Local_UsernameSecret = Get-AzKeyVaultSecret -VaultName $LocalCred_KVName -Name $LocalUsername_Secret -AsPlainText
$Local_PasswordSecret = Get-AzKeyVaultSecret -VaultName $LocalCred_KVName -Name $LocalPassword_Secret -AsPlainText
$Local_SecurePassword = ConvertTo-SecureString -String $Local_PasswordSecret -AsPlainText -Force
# Create PSCredential object
$Local_Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Local_UsernameSecret, $Local_SecurePassword

### Extract Domain Credentials from KV
$Domain_UsernameSecret = Get-AzKeyVaultSecret -VaultName $DomainCred_KVName -Name $DomainUsername_Secret -AsPlainText
$Domain_PasswordSecret = Get-AzKeyVaultSecret -VaultName $DomainCred_KVName -Name $DomainPassword_Secret -AsPlainText
$Domain_SecurePassword = ConvertTo-SecureString -String $Domain_PasswordSecret -AsPlainText -Force
# Create PSCredential object
$Domain_Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Domain_UsernameSecret, $Domain_SecurePassword



## Read CSV file
$vmlist = Import-CSV .\vm-details.csv | Select-Object "VMName","ResourceGroup"

foreach ($vm in $vmlist){
$vmName = $vm.VMName
$vmRG = $vm.ResourceGroup

$vminfo = Get-AzVM -Name $vmName -ResourceGroupName $vmRG

$nicID = $vminfo.NetworkProfile.NetworkInterfaces[0].Id
$nicinfo = Get-AzNetworkInterface -ResourceId $nicID
$vmPrivateIP = $nicinfo.IpConfigurations[0].PrivateIpAddress


$FirewallOff = Invoke-AzVMRunCommand -VM $vminfo  -CommandId 'RunPowerShellScript' -ScriptPath "Firewall_OFF.ps1"
$FirewallOff

$DJoin = Add-Computer -ComputerName $vmPrivateIP -LocalCredential $Local_Cred -DomainName $Domain -Credential $Domain_Cred
$DJoin

$FirewallON = Invoke-AzVMRunCommand -VM $vminfo  -CommandId 'RunPowerShellScript' -ScriptPath "Firewall_ON.ps1"
$FirewallON

Restart-AzVM -Name $vmName -ResourceGroupName $vmRG

    [PSCustomObject]@{
        VMName = $vmName
        FWOff = $FirewallOff
        DomainJoin = $DJoin
        FWOn = $FirewallON
        } | Export-Csv domainjoinstatus.csv -notype -Append
}
### End of Script