﻿param(
    [String] $agentName,
    [String] $labels,
    [int] $numberOfExecutors,
    [string] $javaPath,
    [String] $ApiToken,         # Apitoken for service account
    [string] $jenkinssvcuser,
    [string] $jenkinssvcpass,
    [string] $agentdescription
)

$workDir = "c:\temp\jenkins\$($agentName)"
$workDirEscaped = $workDir.Replace("\", "\\")
$JenkinsUrl = 'http://10.0.0.4:8080'
$JenkinsUser = "jenkinsadmin"   
$jenkinsAgentServiceName = "JenkinsAgent-$($agentName)"

$JSON_OBJECT = @"
{
       "name": "$agentName",
       "nodeDescription": "$agentName test node",
       "numExecutors": "$numberOfExecutors",
       "remoteFS": "$workDirEscaped",
       "labelString": "$labels",
       "mode": "NORMAL",
       "launcher": {
             "stapler-class": "hudson.slaves.JNLPLauncher",
             "class": "hudson.slaves.JNLPLauncher",
             "workDirSettings": {
                    "disabled": true,
                    "workDirPath": "",
                    "internalDir": "remoting",
                    "failIfWorkDirIsMissing": false
             },
             "tunnel": "",
             "vmargs": ""
       },
       "nodeProperties": {
             "stapler-class-bag": "true"
       },
       "type": "hudson.slaves.DumbSlave"
}
"@

$JenkinsSlaveExeConfig = @"
<!-- see http://support.microsoft.com/kb/936707 -->
<configuration>
<runtime>
<generatePublisherEvidence enabled="false"/>
<AppContextSwitchOverrides value="Switch.System.Net.DontEnableSchUseStrongCrypto=false"/>
</runtime>
<startup>
<supportedRuntime version="v4.0" />
<supportedRuntime version="v2.0" />
</startup>
</configuration>
"@

 
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$jenkinsAgentServiceName</id>
<name>$jenkinsAgentServiceName</name>
<description>$agentdescription</description>
<env name="JENKINS_HOME" value="%BASE%"/>   
<executable>$javaPath</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl $JenkinsUrl/computer/$($agentName)/slave-agent.jnlp -secret SecretGoesHere</arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
#SERVICE ACCOUNT DETAILS.
 <serviceaccount>                             
     <user>$jenkinssvcuser</user>
     <password>$jenkinssvcpass</password>
     <allowservicelogon>true</allowservicelogon>
   </serviceaccount>
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" 
               className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension"
               id="killOnStartup">
<pidfile>%BASE%\jenkins_agent.pid</pidfile>
<stopTimeout>5000</stopTimeout>
<stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@


New-Item -ItemType Directory -Path $workDir -Force
cd $workDir

# Create Slave EXE Config file
$JenkinsSlaveExeConfig | Set-Content -Encoding UTF8 Jenkins-slave.exe.config

$pair = $JenkinsUser + ":" + $ApiToken
$encode = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}" -f $pair)))
$Headers = @{ Authorization = ("Basic {0}" -f $encode) } 
$u = $JSON_OBJECT | ConvertTo-Json -Depth 5 -Compress
$e = "json={0}" -f $JSON_OBJECT.Replace("`n", "") 

# Register New Node in Jenkins Master
try {
    $response = Invoke-WebRequest -Headers $Headers -ContentType "application/x-www-form-urlencoded" -Method Post "$JenkinsUrl/computer/doCreateItem?name=$agentName&type=hudson.slaves.DumbSlave" -Body $e    
}
catch { 
    Write-Host "Registered New Node in Jenkins Master."
}


# Get the jnlp - to get to the secret
Invoke-WebRequest -Headers $Headers -Method Post "$JenkinsUrl/computer/$($agentName)/slave-agent.jnlp" -OutFile $workDir\jenkins-slave.jnlp

# Get the secret
$jnlp = [Xml] (Get-Content -Path $workdir\jenkins-slave.jnlp)
$secret = $jnlp.jnlp.'application-desc'.argument[0]    

# Update the slave xml file with secret
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$jenkinsAgentServiceName</id>
<name>$jenkinsAgentServiceName</name>
<description>$agentdescription</description>
<env name="JENKINS_HOME" value="%BASE%"/>   
<executable>$javaPath</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl $JenkinsUrl/computer/$($agentName)/slave-agent.jnlp -secret $($secret) </arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
 <serviceaccount>                             
     <user>$jenkinssvcuser</user>
     <password>$jenkinssvcpass</password>
     <allowservicelogon>true</allowservicelogon>
   </serviceaccount>
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension" id="killOnStartup">
      <pidfile>%BASE%\jenkins_agent.pid</pidfile>
      <stopTimeout>5000</stopTimeout>
      <stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@
 
# Write out the file.
$JenkinsSlaveXml | Set-Content -Encoding UTF8 Jenkins-slave.xml

# Download the agent jar
Invoke-WebRequest -Uri $JenkinsUrl/jnlpJars/agent.jar -OutFile $workDir\slave.jar

# Download Windows Service Wrapper
Invoke-WebRequest -Uri https://github.com/winsw/winsw/releases/download/v2.12.0/WinSW.NET4.exe -OutFile "$workDir\jenkins-slave.exe"

# Install & Start Windows Service Wrapper as a service
& $workDir\jenkins-slave.exe install
& $workDir\jenkins-slave.exe start
           
       