﻿param(
    [String] $ApiToken, # Apitoken for service account
    [string] $jenkinssvcuser,
    [string] $jenkinssvcpass
)

Write-Host "ApiToken: $ApiToken"
Write-Host "jenkinssvcuser: $jenkinssvcuser"
Write-Host "jenkinssvcpass: $jenkinssvcpass"

Write-Host "Importing details from CSV input."
$vmlist = Import-CSV ./powershell/insurityvms.csv | Select-Object "VMName", "ResourceGroup", "AgentName", "Labels", "NumberOfExecutors", "JavaPath", "AgentDescription"

foreach ($vm in $vmlist) {
    Write-Host "Setting the value for parameters."
    $vminfo = Get-AzVM -Name $vm.VMName -ResourceGroupName $vm.ResourceGroup

    $AgentName = $vm.AgentName
    Write-Host "Agent Name: $AgentName"
    $Labels = $vm.Labels
    Write-Host "Labels: $Labels"
    $NumberOfExecutors = $vm.NumberOfExecutors
    Write-Host "NumberOfExecutors: $NumberOfExecutors"
    $JavaPath = $vm.JavaPath
    Write-Host "JavaPath: $JavaPath"
    $AgentDescription = $vm.AgentDescription
    Write-Host "Agent description is: $AgentDescription"
    $jenkinsAgentServiceName = "JenkinsAgent-$($agentName)"
    Write-Host "Jenkins service is: $jenkinsAgentServiceName"

    Write-Host "Checking the agent status in $($vm.VMName)."

    $agentstatus = Invoke-AzVMRunCommand -VM $vminfo -CommandId 'RunPowerShellScript' -ScriptPath "./powershell/Jenkins-agent-status.ps1" -Parameter @{ jenkinsAgentServiceName = $jenkinsAgentServiceName }
    $aggee = $agentstatus.Value[0].Message.Length
    $trr = "0"

    if ($aggee -ne $trr) {
        Write-Host "$($vm.VMName): $jenkinsAgentServiceName service is there, checking the running status."
        $agg = $agentstatus.Value[0].Message.Contains("Running")

        if ($agg) {
            Write-Host "$($vm.VMName): $jenkinsAgentServiceName Service is installed, and it is running."
        }
        else {
            Write-Host "$($vm.VMName): $jenkinsAgentServiceName Service is stopped. Need to restart the service."
            $agentrestart = Invoke-AzVMRunCommand -VM $vminfo -CommandId 'RunPowerShellScript' -ScriptPath "./powershell/Jenkins-agent-restart.ps1" -Parameter @{ jenkinsAgentServiceName = $jenkinsAgentServiceName }
            $agstat = Invoke-AzVMRunCommand -VM $vminfo -CommandId 'RunPowerShellScript' -ScriptPath "./powershell/Jenkins-agent-status.ps1" -Parameter @{ jenkinsAgentServiceName = $jenkinsAgentServiceName }
            $agrestat = $agstat.Value[0].Message.Contains("Running")

            if ($agrestat) {
                Write-Host "$($vm.VMName): $jenkinsAgentServiceName Service is restarted."
            }
            else {
                Write-Host "Unable to restart the $jenkinsAgentServiceName Service in $($vm.VMName). Re-installing the Agent Service."
                $command = Invoke-AzVMRunCommand -VM $vminfo -CommandId 'RunPowerShellScript' -ScriptPath "./powershell/jenkins-agent-install.ps1" -Parameter @{ agentName = $AgentName; labels = $Labels; numberOfExecutors = $NumberOfExecutors; javaPath = $JavaPath; ApiToken = $ApiToken; jenkinssvcuser = $jenkinssvcuser; jenkinssvcpass = $jenkinssvcpass; agentdescription = $AgentDescription }
                $command
                Write-Host "Re-Installed the $jenkinsAgentServiceName Service in $($vm.VMName)."
            }
        }
    }
    else {
        Write-Host "$jenkinsAgentServiceName Service is not installed in $($vm.VMName). Installing the Service."
        $command = Invoke-AzVMRunCommand -VM $vminfo -CommandId 'RunPowerShellScript' -ScriptPath "./powershell/jenkins-agent-install.ps1" -Parameter @{ agentName = $AgentName; labels = $Labels; numberOfExecutors = $NumberOfExecutors; javaPath = $JavaPath; ApiToken = $ApiToken; jenkinssvcuser = $jenkinssvcuser; jenkinssvcpass = $jenkinssvcpass; agentdescription = $AgentDescription }
        $command
        Write-Host "Installed the $jenkinsAgentServiceName Service in $($vm.VMName)."
    }
}
