﻿param(
    [String] $jenkinsAgentServiceName
)
  
Restart-Service -Name $jenkinsAgentServiceName -ErrorAction SilentlyContinue
