﻿param(
    [String] $jenkinsAgentServiceName
)

$status = Get-Service -Name $jenkinsAgentServiceName -ErrorAction SilentlyContinue
$status