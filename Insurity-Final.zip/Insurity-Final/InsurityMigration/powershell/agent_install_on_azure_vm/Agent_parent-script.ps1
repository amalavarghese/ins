﻿$azureAplicationId ="xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"
$azureTenantId= "xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"
$ClientSecret = "xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"

$SubID = "xxxxx-xxxxxxx-xxxxxxxxxxx"


## Login
$azurePassword = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
$psCred = New-Object System.Management.Automation.PSCredential($azureAplicationId , $azurePassword)
Add-AzAccount -Credential $psCred -TenantId $azureTenantId  -ServicePrincipal 

## Set Context to Subscription
Set-AzContext -Subscription $SubID


## Read CSV File
$userobjects = Import-CSV .\vm-details.csv | Select-Object "VMName","ResourceGroup","FluentD","AppDAgent","MachineAgent","LapsAgent","CrowdStrike"

ForEach($userobjects in $userobjects){

##----------------FluentD Installation--------------------##
if($userobjects.FluentD -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $vm = $userobjects.VMName
    $vmsinfo = Get-AzVM -ResourceGroupName $vmrg -Name $vm
    $vmsinrg = $vmsinfo.Name
    
    foreach($vmlist in $vmsinrg){
        Write-Host "$vmlist : Checking FluentD Status"
        $tdagent2 = Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'fluentdstatus.ps1'
        $tda = $tdagent2.Value[0].Message
        $td = $tda.Length
        $trr = "0"
        Write-Host "$tda"
        
        if($td -ne $trr){
            Write-Host "$vmlist : FluentD is installed"
        }
        else{
            Write-Host "$vmlist : FluentD is not installed"
            Write-Host "Copying Agent to $vmlist"
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'fluentdcp.ps1'
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'fluentdinstallation.ps1'
            Write-Host "$vmlist : Td_Agent Installation Successfull"
        }
        
    [PSCustomObject]@{
        VMName = $userobjects.AzureVm
        RGName = $vmrg
        TDAgent = $td
        } | Export-Csv fluentd.csv -notype -Append
    }
}





##-------------------AppDAgent Installation------------------##
if($userobjects.AppDAgent -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $appdvm = $userobjects.VMName
    $appdvmsinfo = Get-AzVM -ResourceGroupName $vmrg -Name $appdvm
    $appdvmsinrg = $appdvmsinfo.Name
    
    foreach($vmlist in $appdvmsinrg){     
        Write-Host "$vmlist : Checking AppD Agent Status"
        $appdagent = Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'AppDynamicsstatus.ps1'
        $appdag = $appdagent.Value[0].Message
        $appdm = $appdag.Length
        $trr = "0"
        Write-Host "$appdag"
        
        if($appdm -ne $trr)
        {
            Write-Host "$vmlist : AppD Agent is installed"
        }
        else{
            Write-Host "$vmlist : AppD Agent is not installed"
            Write-Host "Copying Agent to $vmlist"
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'appdcp.ps1'
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'AppDinstallation.ps1'
            Write-Host "$vmlist : AppD Agent Installation Successfull"
            Write-Host "$vmlist : Stopping Service"
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'stopAppD.ps1'
        }
         
    [PSCustomObject]@{
        VMName = $userobjects.VMName
        RGName = $vmrg
        AppD = $appdm
        } | Export-Csv appsd.csv -notype -Append
    }    
}




##-------------------MachineAgent Installation------------------## We need to modify
if($userobjects.MachineAgent -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $appdvm2 = $userobjects.VMName
    $appdvmsinfo2 = Get-AzVM -ResourceGroupName $vmrg -Name $appdvm2
    $appdvmsinrg2 = $appdvmsinfo2.Name
    
    foreach($vmlist in $appdvmsinrg2){     
        Write-Host "$vmlist : Checking Machine Agent Status"
        $appdagent2 = Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'MachineAgentstatus.ps1'
        $appdag2 = $appdagent2.Value[0].Message
        $appdm2 = $appdag2.Length
        $trr = "0"
        Write-Host "$appdag2"
        
        if($appdm2 -ne $trr)
        {
            Write-Host "$vmlist : Machine Agent is installed"
        }
        else{
            Write-Host "$vmlist : Machine Agent is not installed"
            Write-Host "Copying Agent to $vmlist"
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'MachineAgentcp.ps1'
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'MachineAgentinstallation.ps1'
            Write-Host "$vmlist : Machine Agent Installation Successfull"
        }
         
    [PSCustomObject]@{
        VMName = $userobjects.VMName
        RGName = $vmrg
        AppD = $appdm2
        } | Export-Csv machineagent.csv -notype -Append
    }    
}





##-----------------------------LAPS Agent Installation-----------------------##

if($userobjects.LapsAgent -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $lapsvm = $userobjects.VMName
    $lapsvmsinfo = Get-AzVM -ResourceGroupName $vmrg -Name $lapsvm
    $lapsvmsinrg = $lapsvmsinfo.Name
    
    foreach($vmlist in $lapsvmsinrg){
        Write-Host "$vmlist : Checking LAPS Agent Status"
        $lapsagent = Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'lapsstatus.ps1'
        $lapsag = $lapsagent.Value[0].Message
        $lapsd = $lapsag.Length
        $trr = "0"
        Write-Host "$lapsag"
        
        if($lapsd -ne $trr){
            Write-Host "$vmlist : LAPS Agent is installed"
        }
        else{
            Write-Host "$vmlist : LAPS Agent is not installed"
            Write-Host "Copying Agent to $vmlist"
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'lapscp.ps1'
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'lapsinstallation.ps1'
            Write-Host "$vmlist : LAPS Agent Installation Successfull"
        } 
       
    [PSCustomObject]@{
        VMName = $userobjects.VMName
        RGName = $vmrg
        LAPS = $lapsd
        } | Export-Csv lapagent.csv -notype -Append 
    }
}





##--------------------------------CrowdStrike Installation------------------------##

if($userobjects.CrowdStrike -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $csvm = $userobjects.VMName
    $csvmsinfo = Get-AzVM -ResourceGroupName $vmrg -Name $csvm
    $csvmsinrg = $csvmsinfo.Name
    
    foreach($vmlist in $csvmsinrg){
        Write-Host "$vmlist : Checking CrowdStrike Agent Status"
        $csagent = Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'crowdstrikestatus.ps1'
        $csag = $csagent.Value[0].Message
        $csad = $csag.Length
        $trr = "0"
        Write-Host "$csag"
        
        if($csad -ne $trr){
            Write-Host "$vmlist : CrowdStrike Agent is installed"
        }
        else{
            Write-Host "$vmlist : CrowdStrike Agent is not installed"
            Write-Host "Copying Agent to $vmlist"
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'cscp.ps1'
            Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'Crowdstrikeinstallation.ps1'
            Write-Host "$vmlist : CrowdStrike Agent Installation Successfull"
        } 
       
    [PSCustomObject]@{
        VMName = $userobjects.VMName
        RGName = $vmrg
        CrowdStrike = $csad
        } | Export-Csv CrowdStrike.csv -notype -Append
    }
}




}    
############ End of Script ############