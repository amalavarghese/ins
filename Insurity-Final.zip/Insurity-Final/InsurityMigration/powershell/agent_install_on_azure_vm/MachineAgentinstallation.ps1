﻿Start-Process C:\AppD23.msi -ArgumentList "/quiet /passive" -PassThru
