Start-Process C:\LAPS.x64.msi -ArgumentList "/quiet /passive" -PassThru
