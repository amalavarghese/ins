﻿Start-Process C:\AppD.msi -ArgumentList "/quiet /passive" -PassThru
