Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://stinscanazfiles.file.core.windows.net/insazurefileshare/azurefilesharedir/Agents/LAPS/LAPS.x64.msi?sv=2020-08-04&ss=f&srt=sco&sp=rwdlc&se=2022-04-29T21:58:23Z&st=2022-03-17T13:58:23Z&spr=https,http&sig=XCSTBi4vBXjEkTXD%2BHYuziz74LyJneN0wFJf3WNyXN4%3D'

$destination = "C:\LAPS.x64.msi"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)