﻿Start-Process C:\fluentd.msi -ArgumentList "/quiet /passive" -PassThru
