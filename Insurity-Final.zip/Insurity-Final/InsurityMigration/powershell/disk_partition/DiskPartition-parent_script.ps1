﻿$azureAplicationId ="xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"
$azureTenantId= "xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"
$ClientSecret = "xxxxxxxx-xxxxxxxxxxxxxx-xxxxxxxxxxxx"

$SubID = "xxxxx-xxxxxxx-xxxxxxxxxxx"


## Login
$azurePassword = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
$psCred = New-Object System.Management.Automation.PSCredential($azureAplicationId , $azurePassword)
Add-AzAccount -Credential $psCred -TenantId $azureTenantId  -ServicePrincipal 

## Set Context to Subscription
Set-AzContext -Subscription $SubID


## Read CSV file
$vmlist = Import-CSV .\vm-details.csv | Select-Object "VMName"
$azvm = $vmlist.VMName

####### Disk Partition #######
foreach($vm in $azvm){
$vmName = $vm.VMName
$vmRG = $vm.ResourceGroup

$vminfo = Get-AzVM -Name $vmName -ResourceGroupName $vmRG
$vminfo

# Running PS script to this vm
$command = Invoke-AzVMRunCommand -VM $vminfo  -CommandId 'RunPowerShellScript' -ScriptPath "DataDiskPartition.ps1"
$command

## Generating for status
$msg = $command.Value[0].Message
$msg

$msglength = $command.Value[0].Message.Length
$msglength

## Generating csv Report
    [PSCustomObject]@{
        VMName = $vmName
        RGName = $vmRG
        DiskStatusLength = $msglength
        Diskmsg = $msg
        } | Export-Csv disk.csv -notype -Append

}

##### End of the Script #####