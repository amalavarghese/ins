﻿$disks = Get-Disk | Where partitionstyle -eq 'raw' | sort number

$letters = 70..89 | ForEach-Object { [char]$_ }
$count = 0
$labels = "Local Disk","Local Disk"

$partitionstyle = "GPT"  # MBR or GPT
$allocationUnitSizeKB = 64  # Use it in KB
$allocationUnitSizeBytes = [uint32]($allocationUnitSizeKB * 1KB)
$FileSystemFormatType = "NTFS"


foreach ($disk in $disks) {
    $driveLetter = $letters[$count].ToString()
    $disk | 
    Initialize-Disk -PartitionStyle $partitionstyle -PassThru |
    New-Partition -UseMaximumSize -DriveLetter $driveLetter |
    Format-Volume -FileSystem $FileSystemFormatType -AllocationUnitSize $allocationUnitSizeBytes -NewFileSystemLabel $labels[$count] -Confirm:$false -Force
$count++
}
##### End of the Script #####