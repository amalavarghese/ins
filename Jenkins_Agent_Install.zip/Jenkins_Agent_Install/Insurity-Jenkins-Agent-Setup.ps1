﻿# NOTE - THIS IS PROOF OF CONCEPT MEANT TO GET YOU STARTED.  IT IS NOT MEANT TO BE USED IN PRODUCTION.  YOU WILL NEED TO MODIFY THIS SCRIPT TO FIT YOUR ENVIRONMENT.
 param(
    [String] $agentName = "test-node-06",
    [String] $labels = "motif",
    [String] $numberOfExecutors = 2,
    [String] $ApiToken = '11091e54783da0a1d70a4c6ab37323201e'         # USE PROTECTED VARIABLES.  DO NOT PUT ANYTHING IN PLAIN TEXT IN YOUR SCRIPTS.  SECRETS REMAIN SECRET.
)
$workDir = "c:\temp\jenkins\$($agentName)"
$workDirEscaped = $workDir.Replace("\", "\\")
$JenkinsUrl = 'http://10.0.0.4:8080'
$JenkinsUser = 'jenkinsadmin'   
$serviceName = "JenkinsAgent-$($agentName)"

$JSON_OBJECT = @"
{
       "name": "$agentName",
       "nodeDescription": "$agentName test node",
       "numExecutors": "$numberOfExecutors",
       "remoteFS": "$workDirEscaped",
       "labelString": "$labels",
       "mode": "NORMAL",
       "launcher": {
             "stapler-class": "hudson.slaves.JNLPLauncher",
             "class": "hudson.slaves.JNLPLauncher",
             "workDirSettings": {
                    "disabled": false,
                    "workDirPath": "",
                    "internalDir": "remoting",
                    "failIfWorkDirIsMissing": false
             },
             "tunnel": "",
             "vmargs": ""
       },
       "nodeProperties": {
             "stapler-class-bag": "true"
       },
       "type": "hudson.slaves.DumbSlave"
}
"@

$JenkinsSlaveExeConfig = @"
<!-- see http://support.microsoft.com/kb/936707 -->
<configuration>
<runtime>
<generatePublisherEvidence enabled="false"/>
<AppContextSwitchOverrides value="Switch.System.Net.DontEnableSchUseStrongCrypto=false"/>
</runtime>
<startup>
<supportedRuntime version="v4.0" />
<supportedRuntime version="v2.0" />
</startup>
</configuration>
"@

 
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$serviceName</id>
<name>$serviceName</name>
<description>This service runs an agent for Jenkins automation server.</description>
<env name="JENKINS_HOME" value="%BASE%"/>   
<executable>C:\Program Files\Java\jre-1.8\bin\java.exe</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl http://10.0.0.4:8080/computer/$($agentName)/slave-agent.jnlp -secret SecretGoesHere</arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
<serviceaccount>                              # SERVICE ACCOUNT DETAILS.
    <user>jenkinsadmin</user>
    <password>JenkinsAdmin12345</password>
    <allowservicelogon>true</allowservicelogon>
  </serviceaccount>
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" 
               className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension"
               id="killOnStartup">
<pidfile>%BASE%\jenkins_agent.pid</pidfile>
<stopTimeout>5000</stopTimeout>
<stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@

add-type @"
    using System.Net;    using System.Security.Cryptography.X509Certificates;    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12


New-Item -ItemType Directory -Path $workDir -Force
cd $workDir
$JenkinsSlaveExeConfig | Set-Content -Encoding UTF8 Jenkins-slave.exe.config
$pair = "jenkinsadmin:$ApiToken"
$encode = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}" -f $pair)))
$Auth= "Basic $encode" 
$Headers = @{ Authorization = ("Basic {0}" -f $encode)} 
$u = $JSON_OBJECT | ConvertTo-Json -Depth 5 -Compress
$e = "json={0}" -f $JSON_OBJECT.Replace("`n", "") 

try {
     Invoke-WebRequest -Headers $Headers -ContentType "application/x-www-form-urlencoded" -Method Post "http://10.0.0.4:8080/computer/doCreateItem?name=$agentName&type=hudson.slaves.DumbSlave" -Body $e    
    } catch {
     Write-Host "Registedred New Node in Jenkins Master."
    }

# Get the jnlp - to get to the secret
Invoke-WebRequest -Headers $Headers -Method Post "$JenkinsUrl/computer/$($agentName)/slave-agent.jnlp" -OutFile $workDir\jenkins-slave.jnlp

# Get the secret
$jnlp = [Xml] (Get-Content -Path $workdir\jenkins-slave.jnlp)
$secret = $jnlp.jnlp.'application-desc'.argument[0] 
  

#Update the slave xml file with secret
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$serviceName</id>
<name>$serviceName</name>
<description>This service runs an agent for Jenkins automation server.</description>
<env name="JENKINS_HOME" value="%BASE%"/>   
<executable>C:\Program Files\Java\jre-1.8\bin\java.exe</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl http://10.0.0.4:8080/computer/$($agentName)/slave-agent.jnlp -secret $($secret) </arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
<serviceaccount>                             #  SERVICE ACCOUNT DETAILS.
    <user>jenkinsadmin</user>
    <password>JenkinsAdmin@12345</password>
    <allowservicelogon>true</allowservicelogon>
  </serviceaccount>
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension" id="killOnStartup">
      <pidfile>%BASE%\jenkins_agent.pid</pidfile>
      <stopTimeout>5000</stopTimeout>
      <stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@


# Write out the file.
$JenkinsSlaveXml | Set-Content -Encoding UTF8 Jenkins-slave.xml

# Download the agent jar
Invoke-WebRequest -Uri http://10.0.0.4:8080/jnlpJars/agent.jar -OutFile $workDir\slave.jar

# Download Windows Service Wrapper
Invoke-WebRequest -Uri https://github.com/winsw/winsw/releases/download/v2.12.0/WinSW.NET4.exe -OutFile "$workDir\jenkins-slave.exe"

# Install Windows Service Wrapper as a service
& $workDir\jenkins-slave.exe install
& $workDir\jenkins-slave.exe start
