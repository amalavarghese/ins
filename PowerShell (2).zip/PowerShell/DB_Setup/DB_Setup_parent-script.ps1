$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName","ResourceGroup","SQLType"

ForEach($userobjects in $userobjects){
##----------------SQL_2019_Standard Installation--------------------##
if($userobjects.SQLType -eq 'SQL_2019_Standard'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist SQL_2019_Standard Task Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/DB_Setup/DB_Setup-2019Std.ps1'
        Write-Host "$vmlist : SQL_2019_Standard Installation Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist SQL_2019_Standard Task End Time: $endTime"
     }
}


##----------------SQL_2019_Enterprise Installation--------------------##
if($userobjects.SQLType -eq 'SQL_2019_Enterprise'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist SQL_2019_Enterprise Task Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/DB_Setup/DB_Setup-2019Ent.ps1'
        Write-Host "$vmlist : SQL_2019_Enterprise Installation Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist SQL_2019_Enterprise Task End Time: $endTime"
    }
}


}