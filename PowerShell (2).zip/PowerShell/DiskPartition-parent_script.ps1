﻿
$vmlist = Import-CSV insurityvms.CSV | Select-Object "VMName"

####### Disk Partition #######
foreach($vm in $vmlist){
$vminfo = Get-AzVM -Name $vm

# Running PS script to this vm
$command = Invoke-AzVMRunCommand -VM $vminfo  -CommandId 'RunPowerShellScript' -ScriptPath "./jdk.ps1"
$command

## Generating for status
# $msg = $command.Value[0].Message
# $msg
# $msglength = $command.Value[0].Message.Length
# $msglength

# ## Generating csv Report
#     [PSCustomObject]@{
#         VMName = $vm
#         RGName = $vminfo.ResourceGroupName
#         DiskStatusLength = $msglength
#         Diskmsg = $msg
#         } | Export-Csv disk.csv -notype -Append

 }
##### End of the Script #####