## Read CSV File
$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName","ResourceGroup","ServerType"

# Define the vault name and certificate name
$vaultName = "kv-prd-conn-cac-kv01"
$certName = "wildcard-bridge-insurity-com"

# Retrieve the PFX certificate as a secret
$secret = Get-AzKeyVaultSecret -VaultName $vaultName -Name $certName -AsPlainText

# Define the parameters for the script
$scriptParams = @{"secret" = $secret}

ForEach($userobjects in $userobjects){
##----------------Web Severs Pre_requisites--------------------##
if($userobjects.ServerType -eq 'Web'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : Web VM Pre-requisites Tasks Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/Server_prerequisites/webserver-prerequisites_Bridge.ps1' -Parameter $scriptParams
        Write-Host "$vmlist : Web VM Pre-requisites Tasks Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : Web VM Pre-requisites Tasks End Time: $endTime"
     }
}

##----------------App Severs Pre_requisites--------------------##
if($userobjects.ServerType -eq 'App'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : App VM Pre-requisites Tasks Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/Server_prerequisites/appserver-prerequisites_Bridge.ps1'
        Write-Host "$vmlist : App VM Pre-requisites Tasks Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : App VM Pre-requisites Tasks End Time: $endTime"
     }
}

##----------------Cognos Severs Pre_requisites--------------------##
if($userobjects.ServerType -eq 'Cognos'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : Cognos VM Pre-requisites Tasks Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/Server_prerequisites/cognosweb-prerequisites_Bridge.ps1'
        Write-Host "$vmlist : Cognos VM Pre-requisites Tasks Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : Cognos VM Pre-requisites Tasks End Time: $endTime"
     }
}

}   
############ End of Script ############