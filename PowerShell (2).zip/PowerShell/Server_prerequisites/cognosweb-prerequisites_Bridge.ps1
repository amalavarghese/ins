﻿Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/bridge-prerequisites/Bridge-PreRequisites.zip?sp=r&st=2024-06-25T07:52:03Z&se=2024-07-06T15:52:03Z&spr=https&sv=2022-11-02&sr=b&sig=JYng1gw2QbxqOZ8h1N2vIPB6FF8vb1KtbE7w5zRZI2I%3D'

$destination ="C:\Bridge-PreRequisites.zip"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

Sleep 5

Expand-Archive -Path "C:\Bridge-PreRequisites.zip" -DestinationPath "C:\Temp" -Force

Sleep 5 

#Note:Upadate the variables value as per environment before running the script

###############################################################################
#Global Variables
################################################################################
$setup_location = 'C:\Temp\Bridge-PreRequisites'
Start-Transcript -Path $setup_location\Logs\cognosserverlog.txt

###########################################################################################
# checking for the modules on the machine
############################################################################################

$webAdminModule = get-module -ListAvailable | ? { $_.Name -eq "webadministration" }
If ($webAdminModule -ne $null) { 
    Import-Module WebAdministration
}
#############################################################################################
# importing required module
#############################################################################################

$module = Get-module | Where-Object {$_.Name -match 'ServerManager*'}
if(!$module)
{ Import-module -Name ServerManager 
} else {  }

write-host "Preparing the machine: Starting with installed the required PS modules.." -ForegroundColor Yellow

############################################################################################
# Installing the roles as per the app_role_feature list provided
#############################################################################################

try{
Import-Csv $setup_location\setups\ServerRoles\cognos_roles_features.csv | foreach{ Install-WindowsFeature $_.name } }
catch
{
    $ex = $_.exception
    $exception = $ex.message.tostring()
    Write-Host "$($exception)" -ForegroundColor Red
    Break;
}
Write-Host "Step 1: Installing the roles and features given in the template" -ForegroundColor yellow

Write-Host "step 2: Installing the third party softwares" -ForegroundColor Yellow
#############################################################################################
# Silently Installiing the third party s/w 
#############################################################################################


#installing the "Microsoft System CLR Types for SQL Server 2019"
#----------------------------------------------------------------------
Start-Sleep 10
$package_available_SQL = Get-package | Where-Object { $_.Name -Match "Microsoft System CLR Types for SQL Server 2019*" } | Select Name , version

if($package_available_SQL -eq $null)
{
    $filepath = "$setup_location\setups\SQLSysClrTypes.msi"
    $system_clr_status = Start-Process -FilePath $filepath -ArgumentList "/q" 
    if($system_clr_status) { write-host "Installed Microsoft System CLr with version 15.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft System CLR Types for SQL Server 2019*"}).version
    if($version -match "15.0*")
        {
             write-host "Installed with correct version $($version) of 'Microsoft System CLR Types for SQL Server 2019*" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of Microsoft System CLR Types for SQL Server, needs an update" -ForegroundColor DarkYellow
    
        Write-Host "Uninstalling $($version) of Microsoft System CLR Types for SQL Server 2019" -ForegroundColor DarkYellow

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing Microsoft System CLR Types for SQL Server of version 15.0" -ForegroundColor DarkYellow

        Start-Process -FilePath $filepath -ArgumentList "/q" 
        
    }
}

#Installing SQL Server Native Client
$package_available_SQL = Get-package | Where-Object { $_.Name -Match "Microsoft SQL Server 2012 Native Client*" } | Select Name , version

$MYMSI3=  "$setup_location\setups\SQLServerNativeClient.msi"   

if($package_available_SQL -eq $null)
{
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $MYMSI3 IACCEPTSQLNCLILICENSETERMS=YES /qn /norestart" -Wait
       Write-Host "Installing Microsoft SQL Server 2012 Native Client" -ForegroundColor DarkYellow
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'Microsoft SQL Server 2012 Native Client *'}).version
    if($version -match "7.2*")
        {
             write-host "Installed with correct version $($version) of Microsoft SQL Server 2012 Native Client *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'Microsoft SQL Server 2012 Native Client *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Notepad *'"

        uninstall-package -Name $package_available_SQL.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'Microsoft SQL Server 2012 Native Client *'" -ForegroundColor DarkYellow
        
    Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $MYMSI3 IACCEPTSQLNCLILICENSETERMS=YES /qn /norestart" -Wait
    }
}


#installing the "#installing the "Microsoft WSE 3.0"
#----------------------------------------------------------------------
Start-Sleep 10
$package_available = Get-package | Where-Object { $_.Name -Match "Microsoft WSE 3.0*" } | Select Name , version

if($package_available -eq $null)
{
    $MYMSI=  "$setup_location\setups\MicrosoftWSE3.msi"
    $MYARGS = "/I $MYMSI /quiet"
    Start-Process "msiexec.exe" -ArgumentList $MYARGS -wait -nonewwindow   
    Write-Host "Installed Microsft WSE with Version 3.0" -ForegroundColor DarkYellow 
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft WSE 3.0"}).version
    if($version -match "3.0*")
        {
             write-host "Installed with correct version $($version) of 'Microsoft WSE 3.0" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of Microsoft WSE 3.0, needs an update" -ForegroundColor DarkYellow
  
    $MYMSI="$setup_location\MicrosoftWSE3.msi"
    $MYARGS="/I $MYMSI /quiet"
    Start-Process "msiexec.exe" -ArgumentList $MYARGS -wait -nonewwindow     
    }
}


#installing the "Microsoft Application Request Routing 3.0"
#----------------------------------------------------------------------
Start-Sleep 10
$MYMSI2=  "$setup_location\setups\requestRouter_amd64.msi"
    
$package_available = Get-package | Where-Object { $_.Name -Match "Microsoft Application Request Routing 3.0*" } | Select Name , version

if($package_available -eq $null)
{
    $MYARGS2 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI2`" $MYARGS2" -Wait -nonewwindow 
    Write-Host "Installed Microsoft Application Request Routing 3.0" -ForegroundColor DarkYellow
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft Application Request Routing 3.0"}).version
    if($version -match "3.0*")
        {
             write-host "Installed with correct version $($version) of 'Microsoft Application Request Routing 3.0" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of Microsoft Application Request Routing 3.0, needs an update" -ForegroundColor DarkYellow
   
    $MYARGS2 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI2`" $MYARGS2" -Wait -nonewwindow
    }
}
#this IIS URL needs to be installed only after Web installer, IIS Rewrite has a dependency on the Installer
#installing the IIS URL Rewrite Module 2"
#----------------------------------------------------------------------
Start-Sleep 10
$package_available = Get-package | Where-Object { $_.Name -Match 'IIS URL Rewrite Module 2 *' } | Select Name , version
$MYMSI3=  "$setup_location\setups\rewrite_amd64_en-US.msi"   

if($package_available -eq $null)
{
    $MYARGS3 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI3`" $MYARGS3" -Wait -nonewwindow   
    Write-Host "Installed IIS URL Rewrite module 2" -ForegroundColor DarkYellow
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'IIS URL Rewrite Module 2 *'}).version
    if($version -match "7.2*")
        {
             write-host "Installed with correct version $($version) of IIS URL Rewrite Module 2 *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'IIS URL Rewrite Module 2 *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Notepad *'"

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'IIS URL Rewrite Module 2 *'" -ForegroundColor DarkYellow
        
    $MYARGS3 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI3`" $MYARGS3" -Wait -nonewwindow 
    }
}
#installing the Notepadd ++"
#----------------------------------------------------------------------

$package_available = Get-package | Where-Object { $_.Name -Match 'Notepad *' } | Select Name , version

if($package_available -eq $null)
{
    $filepath = "$setup_location\setups\npp.8.2.exe"
    $notepad_install_status = Start-Process -FilePath $filepath -ArgumentList /S -NoNewWindow -Wait -Passthru
    if($notepad_install_status){ Write-Host "Notepadd ++ is installed with version 8.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'Notepad *'}).version
    if($version -match "8.0*")
        {
             write-host "Installed with correct version $($version) of Notepad *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'Notepad *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Notepad *'" -ForegroundColor DarkYellow

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'Notepad *'" -ForegroundColor DarkYellow
        
        $filepath = "$setup_location\setups\npp.8.2.exe"
        $notepad_install_status = Start-Process -FilePath $filepath -ArgumentList /S -NoNewWindow -Wait -Passthru
    }
}

#instaling the nuget package2 
#----------------------------------------------------------------------------------------------------------------------
$nugetInstalled_Check = Get-PackageProvider -ListAvailable *NuGet* -ErrorAction SilentlyContinue | Select-Object Name -ExpandProperty Name
if($nugetInstalled_Check -like "NuGet"){
Write-Host "NuGet is installed."
} else { Write-Host "NuGet is Not installed, therefore Installing..."
Install-PackageProvider -Name NuGet -Force -Verbose
}

#installing the Java 8 Update 321"
#------------------------------------------------------------------------------------------
Start-Sleep 10
$package_available = Get-package | Where-Object { $_.Name -Match 'Java 8 Update 321*' } | Select Name , version
Start-Sleep 5
if($package_available -eq $null)
{
    $java_install_status = Start-Process -FilePath "$setup_location\setups\jre-8u321-windows-x64.exe" -ArgumentList "/s REBOOT=ReallySuppress" -Wait -PassThru -NoNewWindow     #filepath cannot be chnaged
    if($java_install_status){ Write-Host "Java 8 is installed wth version 8.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'Java 8 Update 321*'}).version
    if($version -match "8.0*")
        {
             write-host "Installed with correct version $($version) of Java 8 Update 321 *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'Java 8 Update 321 *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Java 8 Update 321 *'"

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'Java 8 Update 321 *'"
        
        Start-Process -FilePath "$setup_location\setups\JavaSetup8u321.exe" -ArgumentList "/s REBOOT=ReallySuppress" -Wait -PassThru -NoNewWindow
    }
}

#install the sql module 
#------------------------------------------------------------------------------------
$package_available = Get-package | Where-Object { $_.Name -match 'SqlServer*' } | Select Name , version

if($package_available -eq $null)
{
    Install-Module -Name SqlServer -RequiredVersion 21.1.18256 -Confirm:$false -Force
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'SqlServer*'}).version
    if($version -match "21.1*")
        {
             write-host "Installed with correct version $($version) of SqlServer *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'SqlServer *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'SqlServer *'"

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'SqlServer *'" -ForegroundColor DarkYellow
        
        Install-Module -Name SqlServer -RequiredVersion 21.1.18256
    }
}

Write-Host "Step 4:creating Folders Structure" -fo Yellow
###########################################################################################################################
# Creating Main bridge website and folder structure
###########################################################################################################################
#Change IIS Root Log Folder
New-Item -Path E: -Name Logs -ItemType Directory -Force -ErrorAction SilentlyContinue
#Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.applicationHost/log' -name CentralLogFileMode -Value 'CentralW3C' -ErrorAction SilentlyContinue
#Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.applicationHost/log' -name centralW3CLogFile.directory -value 'E:\Logs' -ErrorAction SilentlyContinue

Start-Sleep 10
@('CognosWebService','BRIDGE_Website_LIVE' , 'BridgeJobQueue_Service') |
ForEach-Object {
New-Item(Join-Path 'E:\' $_ ) -ItemType Directory -Force
}
Start-Sleep -Seconds 5
New-Item -Path E:\CognosWebService -Name CognosAutomation\Licensees -ItemType Directory -Force

New-Item -Path E:\BridgeJobQueue_Service -Name 3.0 -ItemType Directory -Force

Write-Host "Step 6:Creating Shared folder and giving permission to Local Administrator" -ForegroundColor Yellow
#######################################################################################################
#Creating shared folder and giving permission to the local admin
#######################################################################################################
New-SmbShare -Path E:\CognosWebService\CognosAutomation\Licensees -Name CognosLicenseesWebService -Confirm:$false -ErrorAction SilentlyContinue
#Shared folder and giving permission to the local admin
Grant-SmbShareAccess -Name CognosLicenseesWebService -AccountName Administrators -AccessRight Full -Confirm:$false

#setting the drive permission for Network services
$acl = Get-Acl E:
$AccessRule=New-Object System.Security.AccessControl.FileSystemAccessRule ('NETWORK SERVICE', 'FullControl','ContainerInherit,ObjectInherit', 'None', 'Allow')

$acl.SetAccessRule($AccessRule)
($acl | Set-Acl E: )

#Setting Permission for BI User
$acl2 = Get-Acl E:\CognosWebService\CognosAutomation
$AccessRule2=New-Object System.Security.AccessControl.FileSystemAccessRule ('INSCLD\SVCPRBRGCJQ', 'FullControl','ContainerInherit,ObjectInherit', 'None', 'Allow')

$acl.SetAccessRule($AccessRule2)
($acl2 | Set-Acl E:\CognosWebService\CognosAutomation )

Write-Host "Step 7:Setting Network access to MSDTC"
########################################################################################################
# Setting Network Access to MSDTC
########################################################################################################

Set-DtcNetworkSetting -DtcName Local -AuthenticationLevel NoAuth -InboundTransactionsEnabled $True -LUTransactionsEnabled $True -OutboundTransactionsEnabled $True -RemoteAdministrationAccessEnabled $True -RemoteClientAccessEnabled $True -XATransactionsEnabled $False -Confirm:$False

#To check the delegation of MIME type
#Set-WebConfigurationProperty -PSPath 'MACHINE/WEBROOT/APPHOST' -Filter "system.webServer/staticContent/mimeMap[@fileExtension='.zip']" -Name "fileExtension" -Value ".exam"

Stop-Transcript 
Start-Sleep 15
Restart-Computer -Force -Confirm:$false
