$computerName = hostname
$newOU = "OU=WebApp,OU=Bridge,OU=UAT,OU=AzureCanada,DC=insurity,DC=cloud"
$domain = "LDAP://insurity.cloud"


# Define the credentials
$username = "svcdomainjoin"
$password = "k!@4qZB6wyFK_RBy9LWxjZTRK"

# Create a secure string for the password
$securePassword = ConvertTo-SecureString $password -AsPlainText -Force

# Create a PSCredential object
$credential = New-Object System.Management.Automation.PSCredential ($username, $securePassword)

# Create the DirectoryEntry object with the domain and credentials
$directoryEntry = New-Object System.DirectoryServices.DirectoryEntry($domain, $credential.UserName, $credential.GetNetworkCredential().Password)

# Output the distinguishedName property to test the connection
$directoryEntry.distinguishedName



# Load the required .NET types
Add-Type -AssemblyName System.DirectoryServices

# Connect to the domain
#$directoryEntry = New-Object System.DirectoryServices.DirectoryEntry($domain)
#$directoryEntry
# Search for the computer object
$searcher = New-Object System.DirectoryServices.DirectorySearcher($directoryEntry)
$searcher.Filter = "(&(objectClass=computer)(name=$computerName))"
$searcher.SearchScope = [System.DirectoryServices.SearchScope]::Subtree
$searchResult = $searcher.FindOne()
$searchResult
if ($searchResult -ne $null) {
    $computer = $searchResult.GetDirectoryEntry()

    # Connect to the target OU
    $targetOU = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$newOU")

    # Move the computer object to the new OU
    $computer.MoveTo($targetOU)

    # Save the changes
    $computer.CommitChanges()

    Write-Output "Computer '$computerName' has been moved to '$newOU'."
} else {
    Write-Output "Computer '$computerName' not found in the domain."
}
