﻿# NOTE - THIS IS PROOF OF CONCEPT MEANT TO GET YOU STARTED.  IT IS NOT MEANT TO BE USED IN PRODUCTION.  YOU WILL NEED TO MODIFY THIS SCRIPT TO FIT YOUR ENVIRONMENT.
 
$agentName = "AgentNameGoesHere"
$workDir = "c:\temp\jenkins\$($agentName)"
$workDirEscaped = $workDir.Replace("\", "\\")
$labels = "labels go here"
$numberOfExecutors = YourNumberOfExecutorsGoesHere
$JenkinsUrl = 'https://jenkins.oceanwide.com'
$JenkinsUser = 'Jenkins username goes here'
$ApiToken = 'Jenkins pat goes here'   # USE PROTECTED VARIABLES.  DO NOT PUT ANYTHING IN PLAIN TEXT IN YOUR SCRIPTS.  SECRETS REMAIN SECRET.
$serviceName = "JenkinsAgent-$($agentName)"
$JSON_OBJECT = @"
{
       "name": "$agentName",
       "nodeDescription": "$agentName test node",
       "numExecutors": "$numberOfExecutors",
       "remoteFS": "$workDirEscaped",
       "labelString": "$labels",
       "mode": "NORMAL",
       "launcher": {
             "stapler-class": "hudson.slaves.JNLPLauncher",
             "$class": "hudson.slaves.JNLPLauncher",
             "workDirSettings": {
                    "disabled": false,
                    "workDirPath": "",
                    "internalDir": "remoting",
                    "failIfWorkDirIsMissing": false
             },
             "tunnel": "",
             "vmargs": ""
       },
       "nodeProperties": {
             "stapler-class-bag": "true"
       },
       "type": "hudson.slaves.DumbSlave"
}
"@
$JenkinsSlaveExeConfig = @"
<!-- see http://support.microsoft.com/kb/936707 -->
<configuration>
<runtime>
<generatePublisherEvidence enabled="false"/>
</runtime>
<startup>
<supportedRuntime version="v4.0" />
<supportedRuntime version="v2.0" />
</startup>
</configuration>
"@

 
# USE PROTECTED VARIABLES.  DO NOT PUT ANYTHING IN PLAIN TEXT IN YOUR SCRIPTS.  SECRETS REMAIN SECRET (line 66)
 
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$serviceName</id>
<name>$serviceName</name>
<description>This service runs an agent for Jenkins automation server.</description>
<executable>java.exe</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl https://jenkins.oceanwide.com/computer/$($agentName)/slave-agent.jnlp -secret SecretGoesHere</arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" 
               className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension"
               id="killOnStartup">
<pidfile>%BASE%\jenkins_agent.pid</pidfile>
<stopTimeout>5000</stopTimeout>
<stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@
New-Item -ItemType Directory -Path $workDir -Force
cd $workDir
$JenkinsSlaveExeConfig | Set-Content -Encoding UTF8 Jenkins-slave.exe.config
$pair = "UserNameGoesHere:$ApiToken"
$encode= [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
$Auth= "Basic $encode"
$Headers = @{ Authorization = $Auth }
$u = $JSON_OBJECT | ConvertTo-Json -Depth 10 -Compress
$e = "json={0}" -f $JSON_OBJECT.Replace("`n", "") 
# Register the new agent
Invoke-WebRequest -Headers $Headers -Method Post "$JenkinsUrl/computer/doCreateItem?name=$agentName&type=hudson.slaves.DumbSlave" -Body $e
# Get the jnlp - to get to the secret
Invoke-WebRequest -Headers $Headers -Method Post "$JenkinsUrl/computer/$($agentName)/slave-agent.jnlp" -OutFile $workDir\jenkins-slave.jnlp
# Get the secret
$jnlp = [Xml] (Get-Content -Path $workdir\jenkins-slave.jnlp)
# No identifier... seriously?  Hope they never change the order!
$secret = $jnlp.jnlp.'application-desc'.argument[0]
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$serviceName</id>
<name>$serviceName</name>
<description>This service runs an agent for Jenkins automation server.</description>
<executable>java.exe</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl https://jenkins.oceanwide.com/computer/$($agentName)/slave-agent.jnlp -secret $($secret)</arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" 
               className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension"
               id="killOnStartup">
<pidfile>%BASE%\jenkins_agent.pid</pidfile>
<stopTimeout>5000</stopTimeout>
<stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@
# Write out the file.
$JenkinsSlaveXml | Set-Content -Encoding UTF8 Jenkins-slave.xml
# Download the agent jar
Invoke-WebRequest -Uri https://jenkins.oceanwide.com/jnlpJars/agent.jar -OutFile $workDir\slave.jar
# Copy the service wrapper
Copy-Item \\filer01\BID_Team\jenkins-slave.exe "$workDir\jenkins-slave.exe"
# Write out the Jenkins agent xml
sc.exe create $serviceName binpath= "$workDir\Jenkins-slave.exe" start= auto
sc.exe start $serviceName