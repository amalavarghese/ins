## Read CSV File
$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName","ResourceGroup","FluentD","APMdotNet","MachineAgent","LapsAgent","CrowdStrike","Java"

ForEach($userobjects in $userobjects){
##----------------Java Installation--------------------##
if($userobjects.Java -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist Java & Copying Jenkins Slave Task Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/agent_installations/Java_Copy_Install.ps1'
        Write-Host "$vmlist : Java Installation Successfull & Copied Jenkins Slave file"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist Java & Copying Jenkins Slave Task End Time: $endTime"
     }
}

##----------------FluentD Installation--------------------##
if($userobjects.FluentD -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist FluentD Task Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/agent_installations/fluentd_Copy_Install.ps1'
        Write-Host "$vmlist : Td_Agent Installation Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist FluentD Task End Time: $endTime"
    }
}

##-------------------APMdotNet Installation------------------##
if($userobjects.APMdotNet -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $appdvmsinrg = $userobjects.VMName
    
    foreach($vmlist in $appdvmsinrg){ 
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist APMdotNet Task Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/agent_installations/APMdotNet_Copy_Install.ps1'
        Write-Host "$vmlist : APMdotNet Installation & Configuration is Successfull" 
        
        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist APMdotNet Task End Time: $endTime"    
    }
}

##-------------------MachineAgent Installation------------------
if($userobjects.MachineAgent -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $appdvmsinrg2 = $userobjects.VMName
    
    foreach($vmlist in $appdvmsinrg2){ 
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist MachineAgent Task Start Time: $startTime"
                   
        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/agent_installations/MA_Copy_Install.ps1'
        Write-Host "$vmlist : Machine Agent Installation Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist MachineAgent Task End Time: $endTime" 
    }
}

##-----------------------------LAPS Agent Installation-----------------------##
if($userobjects.LapsAgent -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $lapsvmsinrg = $userobjects.VMName
    
    foreach($vmlist in $lapsvmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist LapsAgent Task Start Time: $startTime"
                  
        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/agent_installations/LAPS_Copy_Install.ps1'
        Write-Host "$vmlist : LAPS Agent Installation Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist LapsAgent Task End Time: $endTime" 
    }
}

##--------------------------------CrowdStrike Installation------------------------##
if($userobjects.CrowdStrike -eq 'Yes'){
    $vmrg = $userobjects.ResourceGroup
    $csvmsinrg = $userobjects.VMName
    
    foreach($vmlist in $csvmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist CrowdStrike Task Start Time: $startTime"
         
        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/agent_installations/CrowdStrike_Copy_Install.ps1'
        Write-Host "$vmlist : CrowdStrike Agent Installation Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist CrowdStrike Task End Time: $endTime" 
     }
}
}   
############ End of Script ############