param(
    # Customer Name such as xcc, mw etc.
    [Parameter()]
    [string]
    $CustomerName,

    # Environment Name such as prod, nonprod, uat etc.
    [Parameter()]
    [string]
    $EnvironmentName,

    # Purpose of this environment such as uat, dev etc.
    [Parameter()]
    [string]
    $Purpose,

    # Configuration File Path (Relative Path).
    [Parameter()]
    [string]
    $EnvironmentConfigurationFilePath,

    # Do you want to use existing State Files for modification of Environment?
    # If set to true, script will try to use existing files.
    # If set to false, script will delete existing .tfstate and .plan files.
    [Parameter()]
    [string]
    $UseExistingTerraformFiles,

    # Do you want to generate log file for debug process by Motifworks Team?
    # If set to true, script will generate log file locally.
    [Parameter()]
    [string]
    $GenerateJsonLogFile = 'false',

    # Are you upgrading the environment?
    # If set to true, script will not run the cleanup commands.
    [Parameter()]
    [string]
    $Upgrade = 'false'
)

# Clear screen before you proceed.
Clear-Host

Write-Host "Environment Name is: $($EnvironmentName)"

# Identify Backend Provider configured for environment.
$BackendName = [string]$(Select-String -Path backend.tf -Pattern 'backend')
$BackendName = $BackendName.Substring($BackendName.IndexOf('"') + 1, $BackendName.LastIndexOf('"') - $BackendName.IndexOf('"') - 1)

Write-Host '
********************************************************************************
Detected Backend: ' $BackendName '
********************************************************************************
' `
    -ForegroundColor Cyan

# Get Customer ID.
$PathArray = ([string](Get-Location)).Split('\')
$CustomerId = $PathArray[$PathArray.Length - 3]

# Compose File Names.
$FileNameTerraformState = "$($CustomerId)_$($EnvironmentName).tfstate"
$FileNameTerraformPlan = "$($CustomerId)_$($EnvironmentName).plan"
$FileNameApplicationConfiguration = "$($CustomerId)_$($EnvironmentName)_environment.config"

# Prepare Configuration file.
if (('false', 'no', '0' -contains $UseExistingTerraformFiles.ToLower() ) -or ('true' -eq $Upgrade)) {
    Write-Host '
        ********************************************************************************
        Initializing Environment Configuration...
        ********************************************************************************
        ' `
        -ForegroundColor Cyan

    Copy-Item $EnvironmentConfigurationFilePath $FileNameApplicationConfiguration
    (Get-Content $FileNameApplicationConfiguration) -Replace '{{CLIENT_ID}}', $CustomerId | Set-Content $FileNameApplicationConfiguration
    (Get-Content $FileNameApplicationConfiguration) -Replace '{{CLIENT_NAME}}', $CustomerName | Set-Content $FileNameApplicationConfiguration
    (Get-Content $FileNameApplicationConfiguration) -Replace '{{ENVIRONMENT_NAME}}', $EnvironmentName | Set-Content $FileNameApplicationConfiguration
    (Get-Content $FileNameApplicationConfiguration) -Replace '{{ENVIRONMENT_PURPOSE}}', $Purpose | Set-Content $FileNameApplicationConfiguration
}

if ('azurerm' -eq $BackendName) {
    Write-Host '
    ********************************************************************************
    Retrieving Storage Account Configuration as detected backend is Azure...
    ********************************************************************************
    ' `
        -ForegroundColor Cyan

    $AzureBackendStorageAccountName = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'azure_backend_storage_account_name')
    $AzureBackendStorageAccountName = $AzureBackendStorageAccountName.Substring($AzureBackendStorageAccountName.IndexOf('"') + 1, $AzureBackendStorageAccountName.LastIndexOf('"') - $AzureBackendStorageAccountName.IndexOf('"') - 1)

    $AzureBackendStorageAccountKey = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'azure_backend_storage_account_key')
    $AzureBackendStorageAccountKey = $AzureBackendStorageAccountKey.Substring($AzureBackendStorageAccountKey.IndexOf('"') + 1, $AzureBackendStorageAccountKey.LastIndexOf('"') - $AzureBackendStorageAccountKey.IndexOf('"') - 1)

    $AzureBackendStorageAccountContainer = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'azure_backend_container_name')
    $AzureBackendStorageAccountContainer = $AzureBackendStorageAccountContainer.Substring($AzureBackendStorageAccountContainer.IndexOf('"') + 1, $AzureBackendStorageAccountContainer.LastIndexOf('"') - $AzureBackendStorageAccountContainer.IndexOf('"') - 1)

    if ('false', 'no', '0' -contains $UseExistingTerraformFiles.ToLower() ) {
        Write-Host '
            ********************************************************************************
            Uploading Application Configuration file to Azure...
            If there is any existing file on Azure BLOB Storage, it will get overwritten...
            ********************************************************************************
            ' `
            -ForegroundColor Cyan

        az storage blob upload `
            --account-name $AzureBackendStorageAccountName `
            --account-key $AzureBackendStorageAccountKey `
            --container-name $AzureBackendStorageAccountContainer `
            --overwrite true `
            --file $FileNameApplicationConfiguration
    } elseif ('false' -eq $Upgrade) {
        Write-Host '
            ********************************************************************************
            Downloading Application Configuration file to Azure...
            If there is any existing file on local file system, it will get overwritten...
            ********************************************************************************
            ' `
            -ForegroundColor Cyan

        az storage blob download `
            --account-name $AzureBackendStorageAccountName `
            --account-key $AzureBackendStorageAccountKey `
            --container-name $AzureBackendStorageAccountContainer `
            --overwrite true `
            --file $FileNameApplicationConfiguration `
            --name $FileNameApplicationConfiguration > nul
    }
}

# Get supplied VNET CIDR Address Space.
$ProvidedAddressSpace = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'virtual_network_address_space = ')
try {
    if (![string]::IsNullOrEmpty($ProvidedAddressSpace)) {
        $ProvidedAddressSpace = $ProvidedAddressSpace.Substring($ProvidedAddressSpace.IndexOf('"') + 1, $ProvidedAddressSpace.LastIndexOf('"') - $ProvidedAddressSpace.IndexOf('"') - 1)
    }
}
catch {
    $ProvidedAddressSpace = ""
}

# Load Configuration file into string.
$EnvironmentConfigurationFileContents = Get-Content $FileNameApplicationConfiguration -Raw

# Get Peer Networks configuration.
if ((-1 -eq $EnvironmentConfigurationFileContents.IndexOf('peer_networks')) -or ([string]::IsNullOrEmpty($ProvidedAddressSpace))) {
    Write-Host '
    ********************************************************************************
    This file does not contain configuration for Peer Networks...
    Code will NOT delete any existing VNET Peerings...
    ********************************************************************************
    ' `
        -ForegroundColor Red
}
elseif ('false' -eq $Upgrade) {
    # Extract VNET Peering address block.
    $PeerNetworksContentBlock = $EnvironmentConfigurationFileContents.Substring($EnvironmentConfigurationFileContents.IndexOf('peer_networks'))
    $PeerNetworksContentBlock = $PeerNetworksContentBlock.Substring($PeerNetworksContentBlock.IndexOf('['))
    $PeerNetworksContentBlock = $PeerNetworksContentBlock.Substring(0, $PeerNetworksContentBlock.IndexOf(']') + 1)

    # Extract list of all configured Resource Groups and associated Virtual Networks.
    $ResourceGroupNames = ($PeerNetworksContentBlock `
            -split '\r?\n' | `
            Select-String `
            -Pattern 'resource_group_name = ')
    $VirtualNetworkNames = ($PeerNetworksContentBlock `
            -split '\r?\n' | `
            Select-String `
            -Pattern 'network_name = ')
 
    for ($counter = 0; $counter -lt $ResourceGroupNames.Length; $counter++) {
        # Extract currently matched string.
        $CurrentResourceGroupName = [string]$ResourceGroupNames[$counter]
        $CurrentVirtualNetworkName = [string]$VirtualNetworkNames[$counter]

        # Sanitize strings to extract core values.
        $CurrentResourceGroupName = $CurrentResourceGroupName.Substring( `
                $CurrentResourceGroupName.IndexOf('"') + 1, `
                $CurrentResourceGroupName.LastIndexOf(',') - $CurrentResourceGroupName.IndexOf('"') - 2)

        $CurrentVirtualNetworkName = $CurrentVirtualNetworkName.Substring( `
                $CurrentVirtualNetworkName.IndexOf('"') + 1, `
                $CurrentVirtualNetworkName.LastIndexOf(',') - $CurrentVirtualNetworkName.IndexOf('"') - 2)

        # Extract currently associated Address Prefixes with current values of Resource Group Name and Virtual Network Name.
        $currentAddressPrefixes = $(az network vnet peering list `
                --resource-group $CurrentResourceGroupName `
                --vnet-name $CurrentVirtualNetworkName `
                --query "[?peeringState!='Disconnected'].{Prefix:remoteAddressSpace.addressPrefixes[0]}" `
            | ConvertFrom-Json)

        # Check if address space is already being utilized and is in Connected mode.
        $addressSpaceInUse = 0
        foreach ($currentAddressPrefix in $currentAddressPrefixes) {

            if ($providedAddressSpace -eq $currentAddressPrefix.Prefix) {
                $addressSpaceInUse = 1
            }
        }

        # Error out as you can't continue.
        if ((1 -eq $addressSpaceInUse) -and ('false', 'no', '0' -contains $UseExistingTerraformFiles.ToLower() )) {
            Write-Host '
            ********************************************************************************
            Address space is already listed in VNET Peering and this will cause error...
            Resource Group Name: ' $CurrentResourceGroupName '
            Virtual Network Name: ' $CurrentVirtualNetworkName '
            Exiting...
            ********************************************************************************
            ' `
                -ForegroundColor Red

            Exit
        }

        # Delete all unnecessary VNET Peerings which may cause trouble sometime in future.
        Write-Host '
        ********************************************************************************
        Deleting unused VNET Peerings...
        Resource Group Name: ' $CurrentResourceGroupName '
        Virtual Network Name: ' $CurrentVirtualNetworkName '
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        
        $vnetPeeringsToDelete = $(az network vnet peering list `
                --resource-group $CurrentResourceGroupName `
                --vnet-name $CurrentVirtualNetworkName `
                --query "[?peeringState!='Connected'].{Name:name}" | ConvertFrom-Json)
        
        foreach ($currentPeering in $vnetPeeringsToDelete) {
            Write-Host "Deleting VNET Peering with name: $($currentPeering.Name)"
            az network vnet peering delete `
                --name $currentPeering.Name `
                --resource-group $CurrentResourceGroupName `
                --vnet-name $CurrentVirtualNetworkName
        }        
    }
}

switch ($UseExistingTerraformFiles.ToLower()) {
    { 'false', 'no', '0' -contains $_ } {
        Write-Host '
        ********************************************************************************
        Cleaning Terraform generated files and re-initializing folder...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        Remove-Item .\.terraform\ -Force -Recurse -ErrorAction SilentlyContinue
        Remove-Item .terraform.lock.hcl -Force -ErrorAction SilentlyContinue
        Remove-Item null -ErrorAction SilentlyContinue

        if ('azurerm' -eq $BackendName) {
            az storage blob delete `
                --account-name $AzureBackendStorageAccountName `
                --account-key $AzureBackendStorageAccountKey `
                --container-name $AzureBackendStorageAccountContainer `
                --name $FileNameTerraformState > nul

            az storage blob delete `
                --account-name $AzureBackendStorageAccountName `
                --account-key $AzureBackendStorageAccountKey `
                --container-name $AzureBackendStorageAccountContainer `
                --name "$($FileNameTerraformState).backup" > nul

            az storage blob delete `
                --account-name $AzureBackendStorageAccountName `
                --account-key $AzureBackendStorageAccountKey `
                --container-name $AzureBackendStorageAccountContainer `
                --name $FileNameTerraformPlan > nul

            terraform init `
                -backend-config="storage_account_name=$($AzureBackendStorageAccountName)" `
                -backend-config="access_key=$($AzureBackendStorageAccountKey)" `
                -backend-config="container_name=$($AzureBackendStorageAccountContainer)" `
                -backend-config="key=$($FileNameTerraformState)"
        }
        else {
            Remove-Item $FileNameTerraformState -Force -ErrorAction SilentlyContinue
            Remove-Item "$($FileNameTerraformState).backup" -Force -ErrorAction SilentlyContinue
            Remove-Item $FileNameTerraformPlan -Force -ErrorAction SilentlyContinue

            terraform init
        }

        break
    }
    default { 
        Write-Host '
        ********************************************************************************
        Using existing .tfstate and .plan files if they exist...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan

        if ('azurerm' -eq $BackendName) {
            az storage blob download `
                --account-name $AzureBackendStorageAccountName `
                --account-key $AzureBackendStorageAccountKey `
                --container-name $AzureBackendStorageAccountContainer `
                --overwrite true `
                --file $FileNameTerraformPlan `
                --name $FileNameTerraformPlan
        }

        if ('true' -eq $Upgrade) {
            if ('azurerm' -eq $BackendName) {
                terraform init `
                    -backend-config="storage_account_name=$($AzureBackendStorageAccountName)" `
                    -backend-config="access_key=$($AzureBackendStorageAccountKey)" `
                    -backend-config="container_name=$($AzureBackendStorageAccountContainer)" `
                    -backend-config="key=$($FileNameTerraformState)"
            } else {
                terraform init
            }
        }
    }
}

Write-Host '
********************************************************************************
Validating Scripts...
********************************************************************************
' `
    -ForegroundColor Cyan

terraform validate

Write-Host '
********************************************************************************
Generating / Updating Scripts...
********************************************************************************
' `
    -ForegroundColor Cyan

terraform plan -var-file="$($FileNameApplicationConfiguration)" -out="$($FileNameTerraformPlan)" -state="$($FileNameTerraformState)"

Write-Host '
********************************************************************************
Creating / Updating Resources...
********************************************************************************
' `
    -ForegroundColor Cyan

if ('true', 'yes', '1' -contains $GenerateJsonLogFile.ToLower() ) {
    $env:TF_LOG = 'JSON'
    $env:TF_LOG_PATH = "tf_Log_$($CustomerId)_$($EnvironmentName).json"
}

terraform apply -auto-approve -state="$($FileNameTerraformState)" "$($FileNameTerraformPlan)"

if ('azurerm' -eq $BackendName) {
    az storage blob upload `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --overwrite true `
        --file $FileNameTerraformPlan > nul
}

if ('true', 'yes', '1' -contains $GenerateJsonLogFile.ToLower()) {
    $env:TF_LOG = 'OFF'
}
