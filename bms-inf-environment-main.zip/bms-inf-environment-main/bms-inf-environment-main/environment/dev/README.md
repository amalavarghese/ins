AWS Api-Gateway Terraform module:
---------------------------------

Terraform module to provision API Gateway resources. The root module creates an API Gateway REST API along with configuring tracing, logging, and metrics.

Usage:
------
Api-gateway module with methods, logs and metrics.

module "api_gateway" {
  source = "../../"

  openapi_config = {
    openapi = "3.0.1"
    info = {
      title   = "Rest-Api for Application"
    }
    paths = {
      "/path1" = {
        get = {
          x-amazon-apigateway-integration = {
            httpMethod           = "GET"
            type                 = "HTTP_PROXY"
            uri                  = "https://ip-ranges.amazonaws.com/ip-ranges.json"
          }
        }
        "/path2" = {
          put = {
            x-amazon-apigateway-integration = {
            httpMethod           = "PUT"
            type                 = "HTTP_PROXY"
            uri                  = "https://ip-ranges.amazonaws.com/ip-ranges.json"  
            }
        }
        }
      }
    }
  }
  logging_level = [INFO]
}


Requirements:
-------------
Name	    Version
terraform	>= 0.13
aws      	>= 3.0

Providers:
----------
aws   >= 3.0

Resources:
----------
Name	                                  Type
-----                                    -------
aws_api_gateway_deployment.this	         resource
aws_api_gateway_method_settings.all      resource
aws_api_gateway_rest_api.this            resource
aws_api_gateway_rest_api_policy.this	 resource
aws_api_gateway_stage.this	             resource
aws_api_gateway_vpc_link.this	         resource


