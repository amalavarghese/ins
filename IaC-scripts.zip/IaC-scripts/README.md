# Introduction

This is the core repository for XC Commerce Terraform scripts.

# Windows Prerequisites

1. Ensure that you have Administrator rights and you can install any necessary software(s).

# Azure Prerequisites

1. Subscription owner access.
2. AAD read/write permissions to run the scripts.

# Software Prerequisites

Chocoloatey is highly preferred way to work with PowerShell and all tools.
Recommendation is to follow 1st 2 steps from below and then use [Chocolatey Commands](#chocolatey-commands) as mentioned after this section.

Shall you still choose **NOT** to use Chocoloatey, manual links are mentioned from Sr. 3 onwards.

1. PowerShell 7 - Get latest stable release from: https://github.com/PowerShell/PowerShell/releases
2. Chocolatey - Run this command on PowerShell Administrative Prompt: `Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))`
3. Azure CLI - Get latest stable release from: https://github.com/Azure/azure-cli/releases
4. Terraform - Get latest stable release from: https://www.terraform.io/downloads
5. kubectl - Follow guide at: https://kubernetes.io/docs/tasks/tools/install-kubectl-windows/
6. MySQL CLI - Get latest stable release from: https://dev.mysql.com/downloads/shell/
7. Helm Charts - Follow guide at: https://helm.sh/docs/intro/install/

# Chocolatey Commands

1. Azure CLI: `choco install azure-cli`
2. Terraform: `choco install terraform`
3. kubectl: `choco install kubernetes-cli`
4. MySQL CLI: `choco install mysql-cli`
5. Helm: `choco install kubernetes-helm`

# Logging on to Azure

Run command: `az login --tenant e47c32e6-31ad-4a91-accf-6f14db489d41`

# Wrapper PowerShell Scripts for Terraform

These scripts serve the purpose to handle problems and scenarios that can't be handled by Terraform.

## Creating Resources

Read through `01-terraform-create-resources.ps1` and run with your desired parameters. Here is an example invocation.

`.\01-terraform-create-resources.ps1 -CustomerName xcc -EnvironmentName nprod -Purpose uat -EnvironmentConfigurationFilePath ..\sample_nonprod_environment.config -UseExistingTerraformFiles false`

Append `-GenerateJsonLogFile true` at end shall you wish to generate a log file containing all calls of Terraform for debug purpose.

## Deleting Resources

Read through `02-terraform-delete-resources.ps1` and run with your desired parameters. Here is an example invocation.

`.\02-terraform-delete-resources.ps1 -CustomerName xcc -EnvironmentName nprod -CleanTerraformFiles yes -DeleteProblematicSettings yes -DeleteResourceGroupForcefully yes`

Append `-GenerateJsonLogFile true` at end shall you wish to generate a log file containing all calls of Terraform for debug purpose.
