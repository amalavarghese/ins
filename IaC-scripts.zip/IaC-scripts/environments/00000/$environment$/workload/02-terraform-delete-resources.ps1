param(
    # Customer Name such as xcc, mw etc.
    [Parameter()]
    [string]
    $CustomerName,

    # Environment Name such as prod, nonprod, uat etc.
    [Parameter()]
    [string]
    $EnvironmentName,

    # Do you want to delete all terraform associated generated files post deletiong of Azure Resources?
    # If set to true, it'll delete .terraform folder, .terraform.lock.hcl file, *.tfstate, *.tfstate.backup, *.backup, *.plan files.
    [Parameter()]
    [string]
    $CleanTerraformFiles,

    # Do you want to forcefully delete Diagnostic Settings, Key Vault Secrets, Key Vault Policies and Purge Key Vault?
    # If yes, above assets will be deleted.
    # If no, ONLY Key Vault will be purged directly.
    [Parameter()]
    [string]
    $DeleteProblematicSettings,

    # Do you want to delete Azure Resource Group forcefully?
    # If set to true, it'll delete Azure Resource Group through Azure CLI commands if Terraform fails.
    # If you need to use this, expect a problem to be there in your code.
    [Parameter()]
    [string]
    $DeleteResourceGroupForcefully,

    # Do you want to generate log file for debug process by Motifworks TEam?
    # If set to true, script will generate log file locally.
    [Parameter()]
    [string]
    $GenerateJsonLogFile = 'false'
)

# Clear screen before you proceed.
Clear-Host

# Get Customer ID.
$PathArray = ([string](Get-Location)).Split('\')
$CustomerId = $PathArray[$PathArray.Length - 3]

# Compose File Names.
$FileNameTerraformState = "$($CustomerId)_$($EnvironmentName).tfstate"
$FileNameTerraformPlan = "$($CustomerId)_$($EnvironmentName).plan"
$FileNameApplicationConfiguration = "$($CustomerId)_$($EnvironmentName)_environment.config"

# Identify Backend Provider configured for environment.
$BackendName = [string]$(Select-String -Path backend.tf -Pattern 'backend')
$BackendName = $BackendName.Substring($BackendName.IndexOf('"') + 1, $BackendName.LastIndexOf('"') - $BackendName.IndexOf('"') - 1)

Write-Host '
********************************************************************************
Detected Backend: ' $BackendName '
********************************************************************************
' `
    -ForegroundColor Cyan

if ('azurerm' -eq $BackendName) {
    Write-Host '
        ********************************************************************************
        Retrieving Storage Account Configuration as detected backend is Azure...
        ********************************************************************************
        ' `
        -ForegroundColor Cyan
    
    $AzureBackendStorageAccountName = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'azure_backend_storage_account_name')
    $AzureBackendStorageAccountName = $AzureBackendStorageAccountName.Substring($AzureBackendStorageAccountName.IndexOf('"') + 1, $AzureBackendStorageAccountName.LastIndexOf('"') - $AzureBackendStorageAccountName.IndexOf('"') - 1)
    
    $AzureBackendStorageAccountKey = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'azure_backend_storage_account_key')
    $AzureBackendStorageAccountKey = $AzureBackendStorageAccountKey.Substring($AzureBackendStorageAccountKey.IndexOf('"') + 1, $AzureBackendStorageAccountKey.LastIndexOf('"') - $AzureBackendStorageAccountKey.IndexOf('"') - 1)
    
    $AzureBackendStorageAccountContainer = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'azure_backend_container_name')
    $AzureBackendStorageAccountContainer = $AzureBackendStorageAccountContainer.Substring($AzureBackendStorageAccountContainer.IndexOf('"') + 1, $AzureBackendStorageAccountContainer.LastIndexOf('"') - $AzureBackendStorageAccountContainer.IndexOf('"') - 1)
    
    Write-Host '
        ********************************************************************************
        Downloading Terraform State File from Azure...
        If there is any existing file on local file system, it will get overwritten...
        ********************************************************************************
        ' `
        -ForegroundColor Cyan
    
    az storage blob download `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --overwrite true `
        --file $FileNameTerraformState `
        --name $FileNameTerraformState > nul
    
    az storage blob download `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --overwrite true `
        --file $FileNameTerraformPlan `
        --name $FileNameTerraformPlan > nul
    
    az storage blob download `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --overwrite true `
        --file $FileNameApplicationConfiguration `
        --name $FileNameApplicationConfiguration > nul
}
    
if ('False' -eq (Test-Path $FileNameTerraformState)) {
    Write-Host "Terraform State (.tfstate) file with name $($FileNameTerraformState) does not exist. Aborting..." `
        -ForegroundColor Red
    exit
}

if ('False' -eq (Test-Path $FileNameTerraformPlan)) {
    Write-Host "Terraform Plan (.plan) file with name $($FileNameTerraformPlan) does not exist. Aborting..." `
        -ForegroundColor Red
    exit
}

$JsonFile = (Get-Content "$($FileNameTerraformState)" -Raw) | ConvertFrom-Json

If ($null -eq $JsonFile.resources) {
    Write-Host "Unable to locate Resource Information in Terraform State (.tfstate) file with name $($FileNameTerraformState)"
    exit
}

Write-Host @'
********************************************************************************
Extracting Resource IDs and Diagnostic Settings...
********************************************************************************
'@ `
    -ForegroundColor Cyan

$IdAzureKubernetesService = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_kubernetes_cluster' }).instances[0].attributes.id) 
$IdEventHubNamespace = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_eventhub_namespace' }).instances[0].attributes.id)
$IdKeyVault = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_key_vault' }).instances[0].attributes.id)

if (0 -ne $JsonFile.resources.Where({ $_.type -eq 'azurerm_mysql_server' }).instances.count) {
    $IdMySqlServer = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_mysql_server' }).instances[0].attributes.id)
}

if (0 -ne $JsonFile.resources.Where({ $_.type -eq 'azurerm_mysql_flexible_server' }).instances.count) {
    $IdMySqlFlexibleServer = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_mysql_flexible_server' }).instances[0].attributes.id)
}

$NameResourceGroup = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_resource_group' }).instances[0].attributes.name)
$NameKeyVault = $($JsonFile.resources.Where({ $_.type -eq 'azurerm_key_vault' }).instances[0].attributes.name)

$DiagnosticSettingNameEventHubNamespace = $(az monitor diagnostic-settings list --resource $IdEventHubNamespace --query 'value[0].name')
$DiagnosticSettingNameAzureKubernetesService = $(az monitor diagnostic-settings list --resource $IdAzureKubernetesService --query 'value[0].name')
$DiagnosticSettingNameKeyVault = $(az monitor diagnostic-settings list --resource $IdKeyVault --query 'value[0].name')

if (0 -ne $JsonFile.resources.Where({ $_.type -eq 'azurerm_mysql_server' }).instances.count) {
    $DiagnosticSettingNameMySqlServer = $(az monitor diagnostic-settings list --resource $IdMySqlServer --query 'value[0].name')
}

if (0 -ne $JsonFile.resources.Where({ $_.type -eq 'azurerm_mysql_flexible_server' }).instances.count) {
    $DiagnosticSettingNameMySqlFlexibleServer = $(az monitor diagnostic-settings list --resource $IdMySqlFlexibleServer --query 'value[0].name')
}

Write-Host '
********************************************************************************
Cleaning Azure Resources...
********************************************************************************
' `
    -ForegroundColor Cyan
if ('true', 'yes', '1' -contains $GenerateJsonLogFile.ToLower()) {
    $env:TF_LOG = 'JSON'
    $env:TF_LOG_PATH = "tf_Log_$($CustomerId)_$($EnvironmentName).json"
}

terraform apply -destroy -auto-approve -state="$($FileNameTerraformState)" "$($FileNameTerraformPlan)"

if ('true', 'yes', '1' -contains $GenerateJsonLogFile.ToLower()) {
    $env:TF_LOG = 'OFF'
}

switch ($CleanTerraformFiles.ToLower()) {
    { 'true', 'yes', '1' -contains $_ } {
        Write-Host '
        ********************************************************************************
        Cleaning Terraform generated files...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        Remove-Item .\.terraform\ -Force -Recurse -ErrorAction SilentlyContinue
        Remove-Item .terraform.lock.hcl -Force -ErrorAction SilentlyContinue
        Remove-Item *.tfstate -Force -ErrorAction SilentlyContinue
        Remove-Item *.backup -Force -ErrorAction SilentlyContinue
        Remove-Item *.plan -Force -ErrorAction SilentlyContinue
        break
    }
}

switch ($DeleteProblematicSettings.ToLower()) {
    { 'true', 'yes', '1' -contains $_ } {
        Write-Host '
        ********************************************************************************
        Deleting Diagnostic Settings...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        
        if (0 -ne $DiagnosticSettingNameEventHubNamespace.length) {
            az monitor diagnostic-settings delete --name $DiagnosticSettingNameEventHubNamespace --resource $IdEventHubNamespace
        }
        
        if (0 -ne $DiagnosticSettingNameAzureKubernetesService.length) {
            az monitor diagnostic-settings delete --name $DiagnosticSettingNameAzureKubernetesService --resource $IdAzureKubernetesService
        }
        
        if (0 -ne $DiagnosticSettingNameKeyVault.length) {
            az monitor diagnostic-settings delete --name $DiagnosticSettingNameKeyVault --resource $IdKeyVault
        }
        
        if (0 -ne $DiagnosticSettingNameMySqlServer.length) {
            az monitor diagnostic-settings delete --name $DiagnosticSettingNameMySqlServer --resource $IdMySqlServer
        }
        
        if (0 -ne $DiagnosticSettingNameMySqlFlexibleServer.length) {
            az monitor diagnostic-settings delete --name $DiagnosticSettingNameMySqlFlexibleServer --resource $IdMySqlFlexibleServer
        }
        
        Write-Host '
        ********************************************************************************
        Deleting all Key Vault Secrets...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        
        az keyvault secret list --vault-name $NameKeyVault | ConvertFrom-Json | ForEach-Object { az keyvault secret delete --vault-name $NameKeyVault --name $($_ | Select-Object -ExpandProperty Name) > nul }
        
        
        Write-Host '
        ********************************************************************************
        Deleting all Access Policies...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        
        az keyvault show --name $NameKeyVault --query 'properties.accessPolicies' | ConvertFrom-Json | ForEach-Object { az keyvault delete-policy --name $NameKeyVault --object-id $($_ | Select-Object -ExpandProperty objectId) > nul }
        break
    }
}

switch ($DeleteResourceGroupForcefully.ToLower()) {
    { 'true', 'yes', '1' -contains $_ } {
        Write-Host '
        ********************************************************************************
        Deleting Resource Group forcefully. Please fix problems in TF files...
        ********************************************************************************
        ' `
            -ForegroundColor Cyan
        az group delete --name "$($NameResourceGroup)" --yes
        break
    }
}

# Load Configuration file into string.
$EnvironmentConfigurationFileContents = Get-Content $FileNameApplicationConfiguration -Raw

# Get Peer Networks configuration.
if (-1 -eq $EnvironmentConfigurationFileContents.IndexOf('peer_networks')) {
    Write-Host '
    ********************************************************************************
    This file does not contain configuration for Peer Networks...
    Code will NOT delete any existing VNET Peerings...
    ********************************************************************************
    ' `
        -ForegroundColor Red
}
else {
    # Extract VNET Peering address block.
    $PeerNetworksContentBlock = $EnvironmentConfigurationFileContents.Substring($EnvironmentConfigurationFileContents.IndexOf('peer_networks'))
    $PeerNetworksContentBlock = $PeerNetworksContentBlock.Substring($PeerNetworksContentBlock.IndexOf('['))
    $PeerNetworksContentBlock = $PeerNetworksContentBlock.Substring(0, $PeerNetworksContentBlock.IndexOf(']') + 1)

    # Extract list of all configured Resource Groups and associated Virtual Networks.
    $ResourceGroupNames = ($PeerNetworksContentBlock `
            -split '\r?\n' | `
            Select-String `
            -Pattern 'resource_group_name = ')
    $VirtualNetworkNames = ($PeerNetworksContentBlock `
            -split '\r?\n' | `
            Select-String `
            -Pattern 'network_name = ')
 
    for ($counter = 0; $counter -lt $ResourceGroupNames.Length; $counter++) {
        # Extract currently matched string.
        $CurrentResourceGroupName = [string]$ResourceGroupNames[$counter]
        $CurrentVirtualNetworkName = [string]$VirtualNetworkNames[$counter]

        # Sanitize strings to extract core values.
        $CurrentResourceGroupName = $CurrentResourceGroupName.Substring( `
                $CurrentResourceGroupName.IndexOf('"') + 1, `
                $CurrentResourceGroupName.LastIndexOf(',') - $CurrentResourceGroupName.IndexOf('"') - 2)

        $CurrentVirtualNetworkName = $CurrentVirtualNetworkName.Substring( `
                $CurrentVirtualNetworkName.IndexOf('"') + 1, `
                $CurrentVirtualNetworkName.LastIndexOf(',') - $CurrentVirtualNetworkName.IndexOf('"') - 2)

        # Delete all unnecessary VNET Peerings which may cause trouble sometime in future.
        Write-Host '
        ********************************************************************************
        Deleting unused VNET Peerings...
        Resource Group Name: ' $CurrentResourceGroupName '
        Virtual Network Name: ' $CurrentVirtualNetworkName '
        ********************************************************************************
        ' `
            -ForegroundColor Cyan

        $vnetPeeringsToDelete = $(az network vnet peering list `
                --resource-group $CurrentResourceGroupName `
                --vnet-name $CurrentVirtualNetworkName `
                --query "[?peeringState!='Connected'].{Name:name}" | ConvertFrom-Json)
        
        foreach ($currentPeering in $vnetPeeringsToDelete) {
            Write-Host "Deleting VNET Peering with name: $($currentPeering.Name)"
            az network vnet peering delete `
                --name $currentPeering.Name `
                --resource-group $CurrentResourceGroupName `
                --vnet-name $CurrentVirtualNetworkName
        }        
    }
}

# Extract provided Resource Group Names for Private Zone DNS Entries of MySQL and Key Vault.
$ResourceGroupPrivateDnsMyql = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'mysql_dns_resource_group = ')
$ResourceGroupPrivateDnsKeyVault = [string]$(Select-String -Path $FileNameApplicationConfiguration -Pattern 'key_vault_dns_resource_group = ')

if (0 -eq $ResourceGroupPrivateDnsMyql) {
    Write-Host '
    ********************************************************************************
    There are no Private DNS Zone Entries to delete for MySQL...
    ********************************************************************************
    ' `
        -ForegroundColor Cyan
}
else {
    # Sanitize name of Resource Group for Private DNS Zone Entry of MySQL.
    $ResourceGroupPrivateDnsMyql = $ResourceGroupPrivateDnsMyql.Substring($ResourceGroupPrivateDnsMyql.IndexOf('"') + 1, $ResourceGroupPrivateDnsMyql.LastIndexOf('"') - $ResourceGroupPrivateDnsMyql.IndexOf('"') - 1)

    Write-Host '
    ********************************************************************************
    Deleting Private DNS Zone Entries for MySQL...
    ********************************************************************************
    ' `
        -ForegroundColor Cyan

    az network private-dns record-set a delete `
        --resource-group $ResourceGroupPrivateDnsMyql `
        --zone-name 'privatelink.mysql.database.azure.com' `
        --name "fqdn-mysql-$($CustomerName)-$($CustomerId)-$($EnvironmentName)" `
        --yes
        
    az network private-dns record-set a delete `
        --resource-group $ResourceGroupPrivateDnsMyql `
        --zone-name 'privatelink.mysql.database.azure.com' `
        --name "mysql-$($CustomerName)-$($CustomerId)-$($EnvironmentName)" `
        --yes        
}

if (0 -eq $ResourceGroupPrivateDnsKeyVault.Length) {
    Write-Host '
    ********************************************************************************
    There are no Private DNS Zone Entries to delete for Key Vault...
    ********************************************************************************
    ' `
        -ForegroundColor Cyan
}
else {
    # Sanitize name of Resource Group for Private DNS Zone Entry of MySQL.
    $ResourceGroupPrivateDnsKeyVault = $ResourceGroupPrivateDnsKeyVault.Substring($ResourceGroupPrivateDnsKeyVault.IndexOf('"') + 1, $ResourceGroupPrivateDnsKeyVault.LastIndexOf('"') - $ResourceGroupPrivateDnsKeyVault.IndexOf('"') - 1)

    Write-Host '
    ********************************************************************************
    Deleting Private DNS Zone Entries for Key Vault...
    ********************************************************************************
    ' `
        -ForegroundColor Cyan

    az network private-dns record-set a delete `
        --resource-group $ResourceGroupPrivateDnsKeyVault `
        --zone-name 'privatelink.vaultcore.azure.net' `
        --name "fqdn-kv-$($CustomerName)-$($CustomerId)-$($EnvironmentName)" `
        --yes
        
    az network private-dns record-set a delete `
        --resource-group $ResourceGroupPrivateDnsKeyVault `
        --zone-name 'privatelink.vaultcore.azure.net' `
        --name "kv-$($CustomerName)-$($CustomerId)-$($EnvironmentName)" `
        --yes
}

Write-Host @'
********************************************************************************
Purging Key Vault...
********************************************************************************
'@ `
    -ForegroundColor Cyan

az keyvault purge --name $NameKeyVault

Remove-Item null -ErrorAction SilentlyContinue

Write-Host @'
********************************************************************************
Deleting Terraform State, Plan and Environment configuration files...
********************************************************************************
'@ `
    -ForegroundColor Cyan

Remove-Item null -ErrorAction SilentlyContinue

if ('azurerm' -eq $BackendName) {
    az storage blob delete `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --name $FileNameTerraformState > nul

    az storage blob delete `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --name "$($FileNameTerraformState).backup" > nul

    az storage blob delete `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --name $FileNameTerraformPlan > nul

    az storage blob delete `
        --account-name $AzureBackendStorageAccountName `
        --account-key $AzureBackendStorageAccountKey `
        --container-name $AzureBackendStorageAccountContainer `
        --name $FileNameApplicationConfiguration > nul
}
else {
    Remove-Item $FileNameTerraformState -Force -ErrorAction SilentlyContinue
    Remove-Item "$($FileNameTerraformState).backup" -Force -ErrorAction SilentlyContinue
    Remove-Item $FileNameTerraformPlan -Force -ErrorAction SilentlyContinue
    Remove-Item $FileNameApplicationConfiguration -Force -ErrorAction SilentlyContinue
}
