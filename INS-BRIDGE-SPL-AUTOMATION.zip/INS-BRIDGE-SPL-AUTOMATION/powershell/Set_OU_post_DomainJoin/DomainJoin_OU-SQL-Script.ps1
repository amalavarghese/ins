# Define the parameters
param (
    [string] $computerName,
    [string] $newOU,
    [domain] $domain
)

# Load the required .NET types
Add-Type -AssemblyName System.DirectoryServices

# Connect to the domain
$directoryEntry = New-Object System.DirectoryServices.DirectoryEntry($domain)

# Search for the computer object
$searcher = New-Object System.DirectoryServices.DirectorySearcher($directoryEntry)
$searcher.Filter = "(&(objectClass=computer)(name=$computerName))"
$searcher.SearchScope = [System.DirectoryServices.SearchScope]::Subtree
$searchResult = $searcher.FindOne()

if ($searchResult -ne $null) {
    $computer = $searchResult.GetDirectoryEntry()

    # Connect to the target OU
    $targetOU = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$newOU")

    # Move the computer object to the new OU
    $computer.MoveTo($targetOU)

    # Save the changes
    $computer.CommitChanges()

    Write-Output "Computer '$computerName' has been moved to '$newOU'."
} else {
    Write-Output "Computer '$computerName' not found in the domain."
}
