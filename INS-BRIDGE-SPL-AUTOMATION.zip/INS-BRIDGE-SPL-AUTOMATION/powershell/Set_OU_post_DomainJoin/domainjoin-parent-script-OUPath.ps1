﻿## Read CSV file
$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName","ResourceGroup","ServerType"

ForEach($userobjects in $userobjects){

    if($userobjects.ServerType -eq 'DB'){
        $vmrg = $userobjects.ResourceGroup
        $vmsinrg = $userobjects.VMName
        
        foreach($vmlist in $vmsinrg){

            $SQLOU  = "OU=SQL,OU=Bridge,OU=UAT,OU=AzureCanada,DC=insurity,DC=cloud"
            $domain = "LDAP://insurity.cloud"

            $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join with SQL OU Task Start Time: $startTime"
            Write-Host "$vmlist : Domain Join with SQL OU Task Initiated"

            Invoke-AzVMRunCommand -ResourceGroupName $vmRG -Name $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/Set_OU_post_DomainJoin/DomainJoin_OU-SQL-Script.ps1' -Parameter @{ computerName = $vmlist; newOU = $SQLOU; domain = $domain }

            Write-Host "$vmlist : Completed Domain Join with SQL OU"
            $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join Task End Time: $endTime"
        }
    }    
    else {
        $vmrg = $userobjects.ResourceGroup
        $vmsinrg = $userobjects.VMName
        
        foreach($vmlist in $vmsinrg){

            $WebAppOU   = "OU=WebApp,OU=Bridge,OU=UAT,OU=AzureCanada,DC=insurity,DC=cloud"
            $domain     = "LDAP://insurity.cloud"

            $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join Task with WebApp OU Start Time: $startTime"
            Write-Host "$vmlist : Domain Join Task with WebApp OU Initiated"

            Invoke-AzVMRunCommand -ResourceGroupName $vmRG -Name $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/Set_OU_post_DomainJoin/DomainJoin_OU-WebApp-Script.ps1'

            Write-Host "$vmlist : Completed Domain Join with WebApp OU"
            $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join with WebApp OU Task End Time: $endTime"
        }
            
    }
}
### End of Script