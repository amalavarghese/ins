﻿param(
    [String] $ApiToken, 
    [string] $jenkinssvcuser,
    [string] $jenkinssvcpass
)

Write-Host "Importing details from CSV input."
$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName", "ResourceGroup", "Jenkins", "AgentName", "Labels", "NumberOfExecutors", "AgentDescription"

ForEach($userobjects in $userobjects){
    ##----------------Jenkins Installation--------------------##
    if($userobjects.Jenkins -eq 'Yes'){
        $vmrg = $userobjects.ResourceGroup
        $vmsinrg = $userobjects.VMName
        
        foreach($vmlist in $vmsinrg){
            $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist Jenkins Installation Task Start Time: $startTime"

            Write-Host "Setting the value for parameters."
            $vminfo = Get-AzVM -Name $vmlist -ResourceGroupName $vmrg

            $AgentName = $userobjects.AgentName
            Write-Host "Agent Name: $AgentName"
            $Labels = $userobjects.Labels
            Write-Host "Labels: $Labels"
            $NumberOfExecutors = $userobjects.NumberOfExecutors
            Write-Host "NumberOfExecutors: $NumberOfExecutors"
            $AgentDescription = $userobjects.AgentDescription
            Write-Host "Agent description is: $AgentDescription"
            $service = $AgentName -replace "\s", ""
            $jenkinsAgentServiceName = "JenkinsAgent-$($service)"
            Write-Host "Jenkins service is: $jenkinsAgentServiceName"

            Write-Host "Installing $jenkinsAgentServiceName Service in $($vmlist)."
            $command = Invoke-AzVMRunCommand -VM $vminfo -CommandId 'RunPowerShellScript' -ScriptPath "./powershell/jenkins_agent_install/jenkins-agent-install.ps1" -Parameter @{ agentName = $AgentName; labels = $Labels; numberOfExecutors = $NumberOfExecutors; ApiToken = $ApiToken; agentdescription = $AgentDescription; jenkinsAgentServiceName = $jenkinsAgentServiceName; jenkinssvcuser = $jenkinssvcuser; jenkinssvcpass = $jenkinssvcpass }        
            $command
            Write-Host "Installed $jenkinsAgentServiceName Service in $($vmlist)."
    
            $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist Jenkins Installation Task End Time: $endTime"
         }
    }
}
