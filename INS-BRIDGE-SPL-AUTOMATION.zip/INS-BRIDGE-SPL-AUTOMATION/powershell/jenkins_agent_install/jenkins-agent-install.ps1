﻿param(
    [String] $agentName,
    [String] $labels,
    [int] $numberOfExecutors,
    [String] $ApiToken,
    [string] $jenkinssvcuser,
    [string] $jenkinssvcpass,
    [string] $agentdescription,
    [string] $jenkinsAgentServiceName
) 

$workDir = "E:\jenkins"
$workDirEscaped = $workDir.Replace("\", "\\")
$JenkinsUrl = 'https://jenkins.oceanwide.com'
$JenkinsUser = "INS\tfsbuild"   
$javaPath = "C:\Program Files\Java\jre1.8.0_333\bin\java.exe"

$JSON_OBJECT = @"
{
       "name": "$agentName",
       "nodeDescription": "$agentName test node",
       "numExecutors": "$numberOfExecutors",
       "remoteFS": "$workDirEscaped",
       "labelString": "$labels",
       "mode": "NORMAL",
       "launcher": {
             "stapler-class": "hudson.slaves.JNLPLauncher",
             "class": "hudson.slaves.JNLPLauncher",
             "workDirSettings": {
                    "disabled": true,
                    "workDirPath": "",
                    "internalDir": "remoting",
                    "failIfWorkDirIsMissing": false
             },
             "tunnel": "",
             "vmargs": ""
       },
       "nodeProperties": {
             "stapler-class-bag": "true"
       },
       "type": "hudson.slaves.DumbSlave"
}
"@

$JenkinsSlaveExeConfig = @"
<!-- see http://support.microsoft.com/kb/936707 -->
<configuration>
<runtime>
<generatePublisherEvidence enabled="false"/>
<AppContextSwitchOverrides value="Switch.System.Net.DontEnableSchUseStrongCrypto=false"/>
</runtime>
<startup>
<supportedRuntime version="v4.0" />
<supportedRuntime version="v2.0" />
</startup>
</configuration>
"@

# Add service account to Local Admin group
Write-Host "Adding service account to Local Admin group."
Add-LocalGroupMember -Group "Administrators" -Member "INSCLD\$jenkinssvcuser"

# Set service account with Logon as service permission
Write-Host "Setting logon as service permission to service account."
$Identity = "INSCLD\$jenkinssvcuser"
$privilege = "SeServiceLogonRight"

$CarbonDllPath = "C:\Temp\Carbon-1.6.0\Carbon\bin\Carbon.dll"   
[Reflection.Assembly]::LoadFile($CarbonDllPath)

[Carbon.Lsa]::GrantPrivileges( $Identity , $privilege)

# Invoke GPUpdate on computer to apply policy
Write-Host "Invoke GPUpdate on computer to apply local policy."
GPUpdate

# Create working directory for jenkins
Write-Host "Creating working directory for jenkins and switch to working directory."
New-Item -ItemType Directory -Path $workDir -Force
cd $workDir

# Create Slave EXE Config file
Write-Host "Creating Slave EXE Config file."
$JenkinsSlaveExeConfig | Set-Content -Encoding UTF8 Jenkins-slave.exe.config

$pair = $JenkinsUser + ":" + $ApiToken
$encode = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}" -f $pair)))
$Headers = @{ Authorization = ("Basic {0}" -f $encode) } 
$u = $JSON_OBJECT | ConvertTo-Json -Depth 5 -Compress
$e = "json={0}" -f $JSON_OBJECT.Replace("`n", "") 

# Register New Node in Jenkins Master
Write-Host "Registering New Node in Jenkins Master."
try {
    $response = Invoke-WebRequest -Headers $Headers -ContentType "application/x-www-form-urlencoded" -Method Post "$JenkinsUrl/computer/doCreateItem?name=$agentName&type=hudson.slaves.DumbSlave" -Body $e    
}
catch { 
    Write-Host "Registered New Node in Jenkins Master."
}

# Get the jnlp - to get the secret
Write-Host "Downloading jnlp file to get the secret."
Invoke-WebRequest -Headers $Headers -Method Post "$JenkinsUrl/computer/$($agentName)/slave-agent.jnlp" -OutFile $workDir\jenkins-slave.jnlp

# Get the secret
Write-Host "Generating secret from jnlp file."
$jnlp = [Xml] (Get-Content -Path $workdir\jenkins-slave.jnlp)
$secret = $jnlp.jnlp.'application-desc'.argument[0]   

$encodedAgentName = [uri]::EscapeDataString($agentName)

# Update the slave xml file with secret
$JenkinsSlaveXml = @"
<?xml version="1.0" encoding="utf-8"?>
<service>
<id>$jenkinsAgentServiceName</id>
<name>$jenkinsAgentServiceName</name>
<description>$agentdescription</description>
<env name="JENKINS_HOME" value="%BASE%"/>   
<executable>$javaPath</executable>
<arguments>-Xrs  -jar "%BASE%\slave.jar" -jnlpUrl $JenkinsUrl/computer/$($encodedAgentName)/slave-agent.jnlp -secret $($secret) </arguments>
<logmode>rotate</logmode>
<onfailure action="restart" />
<extensions>
<!-- This is a sample configuration for the RunawayProcessKiller extension. -->
<extension enabled="true" className="winsw.Plugins.RunawayProcessKiller.RunawayProcessKillerExtension" id="killOnStartup">
      <pidfile>%BASE%\jenkins_agent.pid</pidfile>
      <stopTimeout>5000</stopTimeout>
      <stopParentFirst>false</stopParentFirst>
</extension>
</extensions>
</service>
"@
 
# Write out the file.
Write-Host "Creating slave XML file."
$JenkinsSlaveXml | Set-Content -Encoding UTF8 Jenkins-slave.xml

# Download the agent jar
Write-Host "Downloading agent.jar file and saving as slave.jar in working directory."
Invoke-WebRequest -Uri $JenkinsUrl/jnlpJars/agent.jar -OutFile $workDir\slave.jar

Copy-Item "C:\jenkins-slave.exe" -Destination $workDir

# Install & Start Windows Service Wrapper as a service
Write-Host "Install & Start jenkins agent as a service"
sc.exe create $jenkinsAgentServiceName binpath= "$workDir\jenkins-slave.exe" start= auto
sc.exe start $jenkinsAgentServiceName

# Set the service to run with service account
Write-Host "Configuring the service to run with service account"
sc.exe config "$jenkinsAgentServiceName" obj= "INSCLD\$jenkinssvcuser" password= "$jenkinssvcpass"        
       