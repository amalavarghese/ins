﻿param(
    [Parameter(Mandatory=$true)]
    [string]$secret
)

Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/bridge-prerequisites/Bridge-PreRequisites.zip?sp=r&st=2024-06-14T13:43:04Z&se=2024-06-29T21:43:04Z&spr=https&sv=2022-11-02&sr=b&sig=W9ZaDS0V70Tpm3HOpM05hDhObvXsAbq9zGr%2Fvsfbw8M%3D'

$destination ="C:\Bridge-PreRequisites.zip"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

Sleep 5

Expand-Archive -Path "C:\Bridge-PreRequisites.zip" -DestinationPath "C:\Temp" -Force

Sleep 5 

###############################################################################
#Global Variables
################################################################################
$setup_location = 'C:\Temp\Bridge-PreRequisites'
$bytes = [System.Convert]::FromBase64String($secret)
$CertStoreLocation = "Cert:\LocalMachine\My"
$pfxFilePath = "C:\Temp\wildcard-bridge-insurity-com.pfx"

$currentDate = Get-Date -format ddMMyy
Start-Transcript -Path $setup_location\Logs\webserverlog.txt
###########################################################################################
# checking for the modules on the machine
############################################################################################

$webAdminModule = get-module -ListAvailable | ? { $_.Name -eq "webadministration" }
If ($webAdminModule -ne $null) { 
    Import-Module WebAdministration
}
#############################################################################################
# importing required module
#############################################################################################

$module = Get-module | Where-Object {$_.Name -match 'ServerManager*'}
if(!$module)
{ Import-module -Name ServerManager 
} else {  }

write-host "Preparing the machine: Starting with installed the required PS modules.." -ForegroundColor Yellow

############################################################################################
# Installing the roles as per the app_role_feature list provided
#############################################################################################

try{
Import-Csv $setup_location\setups\ServerRoles\web_roles_features.csv | foreach{ Install-WindowsFeature $_.name } }
catch
{
    $ex = $_.exception
    $exception = $ex.message.tostring()
    Write-Host "$($exception)" -ForegroundColor Red
    Break;
}
Write-Host "Step 1: Installing the roles and features given in the template" -ForegroundColor yellow

Write-Host "step 2: Installing the third party softwares" -ForegroundColor Yellow
#############################################################################################
# Silently Installiing the third party s/w 
#############################################################################################

#installing the "Microsoft ASP.NET Core 2.1.30 Hosting Bundle Options"
#----------------------------------------------------------------------

$package_available = Get-package | Where-Object { $_.Name -Match "Microsoft .NET Core Runtime - 2.1.30*" } | Select Name , version

if($package_available -eq $null)
{
    $filepath =  "$setup_location\setups\dotnet-hosting-2.1.30-win.exe"
    $args = New-Object -TypeName System.Collections.Generic.List[System.String]
    
    $args.Add("/quiet")
    $args.Add("/norestart")

    $dotnet_status = Start-Process -FilePath $filepath -ArgumentList $args -NoNewWindow -Wait -PassThru
    if($dotnet_status) { Write-Host "Installed the Package for dotnet-hosting-2.1.30" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green

    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft .NET core 2.1.30 - Windows Server Hosting"}).version
    if($version -match "2.1.30*")
    { write-host "Installed with correct version $($version) of 'Microsoft .NET Core 2.1.30'" -ForegroundColor DarkYellow }
    else {
    #uninstalling will need the exact names of the package name everytime in case you desire to uninstall
    }
}

#installing the "Microsoft ASP.NET Core 3.1.22 Hosting Bundle Options"
#----------------------------------------------------------------------
Start-Sleep 15
$package_available_3 = Get-package | Where-Object { $_.Name -Match "Microsoft .NET Core Runtime - 3.1.22*" } | Select Name , version

if($package_available -eq $null)
{
    $filepath = "$setup_location\setups\dotnet-hosting-3.1.22-win.exe"
    $args = New-Object -TypeName System.Collections.Generic.List[System.String]

    $args.Add("/quiet")
    $args.Add("/norestart")
    
    $dotnet3_status = Start-Process -FilePath $filepath -ArgumentList $args -NoNewWindow -Wait -PassThru
    if($dotnet3_status){
    Write-Host "Installed the Package for dotnet-hosting-3.1.22" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft .NET core 3.1.22 - Windows Server Hosting"}).version
    if($version -match "3.1.22*")
    { write-host "Installed with correct version $($version) of 'Microsoft .NET Core 3.1.22'" -ForegroundColor DarkYellow }
    else {
    #Uninstall-Package | Where-Object {$_.Name -match "Microsoft .NET Core*"
    #uninstalling will nedd the exact names of the package name
    }
}

#installing the "Microsoft System CLR Types for SQL Server 2019"
#----------------------------------------------------------------------
Start-Sleep 10
$package_available_SQL = Get-package | Where-Object { $_.Name -Match "Microsoft System CLR Types for SQL Server 2019*" } | Select Name , version

if($package_available_SQL -eq $null)
{
    $filepath = "$setup_location\setups\SQLSysClrTypes.msi"
    $system_clr_status = Start-Process -FilePath $filepath -ArgumentList "/q" 
    if($system_clr_status) { write-host "Installed Microsoft System CLr with version 15.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft System CLR Types for SQL Server 2019*"}).version
    if($version -match "15.0*")
        {
             write-host "Installed with correct version $($version) of 'Microsoft System CLR Types for SQL Server 2019*" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of Microsoft System CLR Types for SQL Server, needs an update" -ForegroundColor DarkYellow
    
        Write-Host "Uninstalling $($version) of Microsoft System CLR Types for SQL Server 2019" -ForegroundColor DarkYellow

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing Microsoft System CLR Types for SQL Server of version 15.0" -ForegroundColor DarkYellow

        Start-Process -FilePath $filepath -ArgumentList "/q" 
        
    }
}

#installing the "#installing the "Microsoft WSE 3.0"
#----------------------------------------------------------------------
Start-Sleep 10
$msiPath = "$setup_location\setups\Microsoft WSE 3.0_standalone.msi"
$package_available = Get-package | Where-Object { $_.Name -Match "Microsoft WSE 3.0*" } | Select Name , version

if($package_available -eq $null)
{
    $installArgs = "/qn /norestart"
    $p = Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$msiPath`" $installArgs" -Wait
    $p.ExitCode   
    if($p) { Write-Host "Installed with Microsft WSE with Version 3.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft WSE 3.0"}).version
    if($version -match "3.0*")
        {
             write-host "Installed with correct version $($version) of 'Microsoft WSE 3.0" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of Microsoft WSE 3.0, needs an update" -ForegroundColor DarkYellow
  
    $installArgs = "/qn /norestart"
    $p = Start-Process -FiePath msiexec.exe -ArgumentList "/i `"$msiPath`" $installArgs" -Wait
    $p.ExitCode   
    }
}


#installing the "Microsoft Application Request Routing 3.0"
#----------------------------------------------------------------------
Start-Sleep 10
$MYMSI2=  "$setup_location\setups\requestRouter_amd64.msi"
    
$package_available = Get-package | Where-Object { $_.Name -Match "Microsoft Application Request Routing 3.0*" } | Select Name , version

if($package_available -eq $null)
{
    $MYARGS2 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI2`" $MYARGS2" -Wait -nonewwindow 
    Write-Host "Installed Microsoft Application Request Routing 3.0" -ForegroundColor DarkYellow
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match "Microsoft Application Request Routing 3.0"}).version
    if($version -match "3.0*")
        {
             write-host "Installed with correct version $($version) of 'Microsoft Application Request Routing 3.0" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of Microsoft Application Request Routing 3.0, needs an update" -ForegroundColor DarkYellow
   
    $MYARGS2 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI2`" $MYARGS2" -Wait -nonewwindow
    }
}
#installing the IIS URL Rewrite Module 2"
#----------------------------------------------------------------------
$package_available = Get-package | Where-Object { $_.Name -Match 'IIS URL Rewrite Module 2 *' } | Select Name , version
$MYMSI3=  "$setup_location\setups\rewrite_amd64_en-US.msi"   

if($package_available -eq $null)
{
    $MYARGS3 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI3`" $MYARGS3" -Wait -nonewwindow   
    Write-Host "Installed IIS URL Rewrite module 2" -ForegroundColor DarkYellow
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'IIS URL Rewrite Module 2 *'}).version
    if($version -match "7.2*")
        {
             write-host "Installed with correct version $($version) of IIS URL Rewrite Module 2 *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'IIS URL Rewrite Module 2 *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Notepad *'"

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'IIS URL Rewrite Module 2 *'" -ForegroundColor DarkYellow
        
    $MYARGS3 = "/qn /norestart"
    Start-Process -FilePath msiexec.exe -ArgumentList "/i `"$MYMSI3`" $MYARGS3" -Wait -nonewwindow 
    }
}
#installing the Notepadd ++"
#----------------------------------------------------------------------
Start-Sleep 10
$package_available = Get-package | Where-Object { $_.Name -Match 'Notepad *' } | Select Name , version

if($package_available -eq $null)
{
    $filepath = "$setup_location\setups\npp.8.2.exe"
    $notepad_install_status = Start-Process -FilePath $filepath -ArgumentList /S -NoNewWindow -Wait -Passthru
    if($notepad_install_status){ Write-Host "Notepadd ++ is installed with version 8.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'Notepad *'}).version
    if($version -match "8.0*")
        {
             write-host "Installed with correct version $($version) of Notepad *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'Notepad *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Notepad *'" -ForegroundColor DarkYellow

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'Notepad *'" -ForegroundColor DarkYellow
        
        $filepath = "$setup_location\setups\npp.8.2.exe"
        $notepad_install_status = Start-Process -FilePath $filepath -ArgumentList /S -NoNewWindow -Wait -Passthru
    }
}

#instaling the nuget package2 
#----------------------------------------------------------------------------------------------------------------------
$nugetInstalled_Check = Get-PackageProvider -ListAvailable *NuGet* -ErrorAction SilentlyContinue | Select-Object Name -ExpandProperty Name
if($nugetInstalled_Check -like "NuGet"){
Write-Host "NuGet is installed."
} else { Write-Host "NuGet is Not installed, therefore Installing..."
Install-PackageProvider -Name NuGet -Force -Verbose
}
#installing the Java 8 Update 321"
#------------------------------------------------------------------------------------------

$package_available = Get-package | Where-Object { $_.Name -Match 'Java 8 Update 321*' } | Select Name , version
Start-Sleep 5
if($package_available -eq $null)
{
    $java_install_status = Start-Process -FilePath "$setup_location\setups\jre-8u321-windows-x64.exe" -ArgumentList "/s REBOOT=ReallySuppress" -Wait -PassThru -NoNewWindow      #filepath cannot be chnaged
    if($java_install_status){ Write-Host "Java 8 is installed wth version 8.0" -ForegroundColor DarkYellow }
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'Java 8 Update 321*'}).version
    if($version -match "8.0*")
        {
             write-host "Installed with correct version $($version) of Java 8 Update 321 *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'Java 8 Update 321 *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'Java 8 Update 321 *'"

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'Java 8 Update 321 *'"
        
        Start-Process -FilePath "$setup_location\setups\jre-8u321-windows-x64.exe" -ArgumentList "/s REBOOT=ReallySuppress" -Wait -PassThru -NoNewWindow
    }
}

#install the sql module 
#------------------------------------------------------------------------------------
$package_available = Get-package | Where-Object { $_.Name -match 'SqlServer*' } | Select Name , version

if($package_available -eq $null)
{
    Install-Module -Name SqlServer -RequiredVersion 21.1.18256 -Confirm:$false -Force
}
else {
    write-host " Already available" -ForegroundColor Green
    #checking for the versions
    $version = (Get-package | Where-Object {$_.Name -match 'SqlServer*'}).version
    if($version -match "21.1*")
        {
             write-host "Installed with correct version $($version) of SqlServer *" -ForegroundColor DarkYellow 
        }
    else { write-host "Installed with version $($version) of 'SqlServer *'" -ForegroundColor DarkYellow
         Write-Host "Uninstalling $($version) of 'SqlServer *'"

        uninstall-package -Name $package_available.Name -AllVersions -Force -Confirm:$true
        Write-Host "Installing 'SqlServer *'" -ForegroundColor DarkYellow
        
        Install-Module -Name SqlServer -RequiredVersion 21.1.18256
    }
}

write-host "Step 3:Creating WCF Site,Physical folder and app pool" -ForegroundColor Yellow
############################################################################################################
# Creating WCF service site, physical folder and app pool along with compliance wcf service 
############################################################################################################ 

Start-sleep -Seconds 5
#Creating a site with sitename, Physical Folder and the Virtual folder name

$SiteName = "WCF_Service"
$PhysicalFolder = "E:"
$VirtualFolder_name = 'WCF_Service'

#Creating a site
$SiteName = "WCF_Service"
$PhysicalFolder = "E:"
$VirtualFolder_name = 'WCF_Service'
$sub_sitename = 'ComplianceService'
$sub_virtualpath = $PhysicalFolder + '\' + $VirtualFolder_name + '\' + $sub_sitename

#create an app pool
$application_pool = 'WCF_Service_AppPool'

#Changing IIS Root Log Folder
New-Item -Path $PhysicalFolder -Name Logs -ItemType Directory -Force -ErrorAction SilentlyContinue
#Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.applicationHost/log' -name CentralLogFileMode -Value 'CentralW3C' -ErrorAction SilentlyContinue
#Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter 'system.applicationHost/log' -name centralW3CLogFile.directory -value 'E:\Logs' -ErrorAction SilentlyContinue

#Checking if the folder WCF service and the sub site folder exists.
#IF WCF service does not exist then we are creating it with a physical folder of Directory type and if sub site directory doesnt exists we are creating the same. 
try
{
$wcf_path = $PhysicalFolder + '\' + $SiteName
$sub_folder = 'ComplianceService'
if(-not (Get-Item -Path $wcf_path -ErrorAction SilentlyContinue))
{
    #Creating a folder wcf_service
    Write-Host -foregroundcolor DarkGreen "Creating website Folder: " -NoNewLine;
    
    Start-Sleep -Seconds 5
    #creating a folder for WCF_service
    New-Item -Path $PhysicalFolder -Name $VirtualFolder_name -ItemType Directory -ErrorAction SilentlyContinue 
    Write-Host "created a wcf_service folder " -ForegroundColor Yellow
    #creating sub folder complainec_service

    Start-Sleep -Seconds 5
    New-item -Path $PhysicalFolder\$VirtualFolder_name -Name $sub_folder -ItemType Directory -ErrorAction SilentlyContinue
    Write-Host "created a sub folder Compliance service" -ForegroundColor Yellow
}
elseif((Get-Item -Path $wcf_path) ) {
    if(-not(Get-Item -Path $wcf_path\$sub_folder -ErrorAction SilentlyContinue)){
        
        Start-Sleep -Seconds 5
        New-item -Path $PhysicalFolder\$VirtualFolder_name -Name $sub_folder -ItemType Directory -ErrorAction SilentlyContinue
        Write-Host "created a sub folder ComplianceService" -ForegroundColor Yellow
    }
    else
    {   
    write-host "We already have the $($VirtualFolder_name) folder and the sub folder $($sub_folder)" -ForegroundColor Yellow
    }
    #Remove-Item -Path $wcf_path -Recurse -Force -Confirm:$false
}


Start-Sleep -Seconds 10
#Checking if the site exists , if not creating one using the sitename and binding information 127.0.0.1:80:
if(-not (Get-IISSite -Name $SiteName -ErrorAction SilentlyContinue ))
{
    #Creating a site
    Write-Host -foregroundcolor DarkGreen "Creating Site: " -NoNewLine;
    
    Start-Sleep -Seconds 5
    $Virtual_folder_path = $PhysicalFolder + '\' + $VirtualFolder_name
    New-IISSite -Name $SiteName -PhysicalPath $Virtual_folder_path -BindingInformation "127.0.0.1:80:" -Force 
    
    #creating a folder for WCF_service
    New-Item -Path 'E:\WCF_service' -Name 'ComplianceService' -ItemType Directory -ErrorAction SilentlyContinue

    #Converting the compliance folder to application
    ConvertTo-WebApplication 'IIS:\Sites\WCF_Service\ComplianceService' -Force
}
else { 
    Write-Host -foregroundcolor DarkCyan "Site already exists,, one need to remove the same"
    
    if((Get-WebApplication -Name $sub_sitename -ErrorAction SilentlyContinue))
    {
    
    Start-Sleep -Seconds 5
    Write-Host -foregroundcolor DarkCyan "$($SiteName) site is removing..."
    Write-Host -ForegroundColor DarkCyan "$($sub_sitename)Application exists"
    #Remove-IISSite -Name $SiteName -Confirm:$false -ErrorAction SilentlyContinue
    } 
    else {
        #Converting the compliance folder to application
        ConvertTo-WebApplication 'IIS:\Sites\WCF_Service\complianceService' -Force
    }
}

Start-Sleep -Seconds 5
#Application pool creation 
if(Get-Item IIS:\AppPools\WCF_Service_AppPool -ErrorAction SilentlyContinue)
{
    Write-Host "App pool WCF_Service already exists" -ForegroundColor Yellow
}
else {
    Write-Host "We need to create the app pool " -ForegroundColor Yellow
    New-item IIS:\AppPools\WCF_Service_AppPool -Force 
    
    #Authentication type for App pool
    Set-ItemProperty IIS:\AppPools\WCF_Service_AppPool -name processModel.identityType -value 2 

    #assigning the app pool to the site
    Set-ItemProperty IIS:\Sites\$SiteName -name ApplicationPool -value $application_pool

    #assigning app pool to the webapplication
    Set-ItemProperty IIS:\Sites\WCF_Service\ComplianceService -name applicationPool -value $application_pool
}
}

catch {
    Write-Host $_.exception.Message
}

Write-Host "Step 4:creating Main Bridge Website" -fo Yellow
###########################################################################################################################
# Creating folder structure Website_LIVE
###########################################################################################################################

$site_name = 'WebServices'
$website_path = 'E:\BRIDGE_Website_LIVE'
$application_pool_name = 'WebServices'
$foldername = 'BRDIGE_Website_LIVE'

##For app Servers creating the folders and sub folders

@('FUX_Website_LIVE' , 'FIA_Website_LIVE' , 'BRIDGE_Website_LIVE' ) |
ForEach-Object {
New-Item(Join-Path 'E:\' $_ ) -ItemType Directory -Force
}
Start-Sleep -Seconds 5
New-Item -Path E:\BRIDGE_Website_LIVE -Name Temporaryfiles\ImportExport -ItemType Directory -Force


#creating app pool
<#if(-not(Get-IISSite -Name $site_name))
{
    write-host "Site $($site_name) is not present we are creating one..." -ForegroundColor Yellow
    #creating site for 
    New-IISSite -Name $site_name -PhysicalPath $website_path -BindingInformation '*:90:' -Force
}
else{} 

Start-Sleep -Seconds 5
#Application pool creation 
if(Get-Item IIS:\AppPools\$site_name -ErrorAction SilentlyContinue)
{
    Write-Host "App pool Website already exists" -ForegroundColor Yellow
}
else {
    write-host "We are creating the application pool" -ForegroundColor Yellow
    New-item IIS:\AppPools\$site_name -Force 
    
    #Authentication type for App pool
    Set-ItemProperty IIS:\AppPools\$site_name -name processModel.identityType -value 2 

    #assigning the app pool to the site
    Set-ItemProperty IIS:\Sites\$site_name -name ApplicationPool -value $application_pool_name
   
}
#>

Write-Host "Step 6:Craeting Shared folder and giving permission to Local Administrator" -ForegroundColor Yellow
#######################################################################################################
#Creating shared folder and giving permission to the local admin
#######################################################################################################
New-SmbShare -Path E:\BRIDGE_Website_LIVE -Name BRIDGE_Website_LIVE -Confirm:$false -ErrorAction SilentlyContinue
#Shared folder and giving permission to the local admin
Grant-SmbShareAccess -Name BRIDGE_Website_LIVE -AccountName Administrators -AccessRight Full -Confirm:$false

#setting the drive permission for Network services
$acl = Get-Acl E:
$AccessRule=New-Object System.Security.AccessControl.FileSystemAccessRule ('NETWORK SERVICE', 'FullControl','ContainerInherit,ObjectInherit', 'None', 'Allow')

$acl.SetAccessRule($AccessRule)
($acl | Set-Acl E: )

Write-Host "Step 7:Setting Network access to MSDTC"
########################################################################################################
# Setting Network Access to MSDTC
########################################################################################################

Set-DtcNetworkSetting -DtcName Local -AuthenticationLevel NoAuth -InboundTransactionsEnabled $True -LUTransactionsEnabled $True -OutboundTransactionsEnabled $True -RemoteAdministrationAccessEnabled $True -RemoteClientAccessEnabled $True -XATransactionsEnabled $False -Confirm:$False


#####################################################################################################################
#Update .Net config
######################################################################################################################

#add an attribute machinekey in web.config file
Start-Sleep 10
$file = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\web.config"
Copy-Item -Path $file -Destination C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\web_"$currentDate".config
([xml]$var = Get-Content -Path $file -OutVariable var) 

#check if the machine key already exists
$web_attributes = ($var.configuration.'system.web').machineKey
if($web_attributes)
{
Write-Host "Attribute machine key is already present"
}
else{
Write-Host "We need to create the machine key element" -ForegroundColor Yellow
Write-Host "-------------------------------------------------------------------------------" -ForegroundColor Yellow
$var_element = $var.CreateElement('machineKey')
$var_location = $var.configuration.'system.web'.AppendChild($var_element)
$var_location.SetAttribute('validation' , '3DES')
$var.Save($file)
Write-Host "We have updated the element machinekey with validation .." -ForegroundColor Yellow
}

#update an attribute pages in web.config file
([xml]$var2 = Get-Content -Path $file)
$var_update = $var2.SelectNodes("/configuration/system.web/pages")
$var_update.SetAttribute('enableViewStateMac' , 'true')
$var2.Save($file)

#Add the transaction timeout in machine config
Start-sleep 10
$file2 = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config"
Copy-Item -Path $file2 -Destination C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine_"$currentDate".config
$newContentAfter = @"
    <system.transactions>
        <defaultSettings timeout="08:00:00" />
        <machineSettings maxTimeout="12:00:00" />
    </system.transactions>
"@

# Check if the <system.transactions> block already exists in the file
$ConfigContent = Get-Content -Path $file2 -Raw
if ($ConfigContent -match "<system.transactions>") {
    Write-Host "<system.transactions> block already exists in the configuration file."
} else {
    # Locate the insertion point after </system.web> if it exists
    $systemWebIndex = $ConfigContent.IndexOf("</system.web>")
    
    if ($systemWebIndex -ne -1) {
        $newLineIndex = $ConfigContent.IndexOf("`n", $systemWebIndex + "</system.web>".Length) + 1
        $newConfigContent = $ConfigContent.Insert($newLineIndex, $newContentAfter)
        Set-Content -Path $file2 -Value $newConfigContent
        Write-Host "Inserted <system.transactions> block into the configuration file."
    } else {
        Write-Host "Error: '</system.web>' tag not found in the configuration file."
    }
}
#Commented this part as not wokring properly and need to work upon
<#Update server Runtime mode
$appconfigpath = "C:\Windows\System32\inetsrv\config\applicationHost.config"
Copy-Item -Path $appconfigpath -Destination C:\Windows\System32\inetsrv\config\applicationHost_"$currentDate".config
$oldLine = '      <section name="serverRuntime" overrideModeDefault="Deny" />'
$newLine = '      <section name="serverRuntime" overrideModeDefault="Allow" />' 
# Read the XML file 
$xmlContent = Get-Content $appconfigpath 
# Loop through each line 
for ($i = 0; $i -lt $xmlContent.Length; $i++) {    
 $line = $xmlContent[$i]          
#Check the line if exist
if ($line.Trim() -eq $oldLine.Trim()) {         
# Replace the old line with the new line         
$xmlContent[$i] = $newLine     
} 
}
# Write the modified content back to the file 
$xmlContent | Set-Content $appconfigpath
#>

######################################################################################################################
#Enable application request Routing Proxy in IIS
##########################################################################################################################
Start-sleep 10
Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST'  -filter "system.webServer/proxy" -name "enabled" -value "True"




##############################################################################################################
#Installing SSL Certficate
##############################################################################################################

# Write the byte array to the .pfx file
[System.IO.File]::WriteAllBytes($pfxFilePath, $bytes)

#Import the pfx certficate
$Cert = Import-PfxCertificate -FilePath $pfxFilePath -CertStoreLocation $CertStoreLocation 

Write-Output "Certficate installed successfully"
Write-Output $cert

Stop-Transcript 
Start-Sleep 15
Restart-Computer -Force -Confirm:$false