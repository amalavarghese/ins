Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/caagents/FluentD/fluentd.msi?sp=r&st=2024-06-14T08:17:49Z&se=2024-06-30T16:17:49Z&spr=https&sv=2022-11-02&sr=b&sig=5ub7Hhd2o%2FSFhn8rsnhxubfTIJEzxW%2BFqXi38SG9WqI%3D'

$destination = "C:\fluentd.msi"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

Start-Process C:\fluentd.msi -ArgumentList "/quiet /passive" -PassThru