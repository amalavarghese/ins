Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

# Copying Java .exe File
$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/caagents/jdk-8u333-windows-x64.exe?sp=r&st=2024-06-14T08:18:53Z&se=2024-06-30T16:18:53Z&spr=https&sv=2022-11-02&sr=b&sig=%2BTEBJ91A0qg8c8dQkqrawD8YACljgOnFkYohLoWkTak%3D'
$destination = "C:\jdk-8u333-windows-x64.exe"
(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

Start-Process -FilePath "C:\jdk-8u333-windows-x64.exe" -ArgumentList "/s" -PassThru


## Adding Jenkins Master ip address to VM host file.
Add-Content -Path $env:windir\System32\drivers\etc\hosts -Value "192.168.0.32    jenkins.oceanwide.com" -Force


## Downloading Jenkins Slave .exe file
$BlobUri2 = 'https://pypzstlevel0.blob.core.windows.net/caagents/jenkins-slave.exe?sp=r&st=2024-06-14T08:19:34Z&se=2024-06-30T16:19:34Z&spr=https&sv=2022-11-02&sr=b&sig=24YxX%2Fl%2BUoMEcFR%2FB5ybZLxOi4xtiVc2i1Da4M8nc9o%3D'
$destination2 = "C:\jenkins-slave.exe"
(New-Object System.Net.WebClient).DownloadFile($BlobUri2, $destination2)


## Downloading Carbon module for service configuration
$BlobUri3 = 'https://pypzstlevel0.blob.core.windows.net/caagents/Carbon-1.6.0.zip?sp=r&st=2024-06-14T08:20:13Z&se=2024-06-30T16:20:13Z&spr=https&sv=2022-11-02&sr=b&sig=daVFqrouej4chx%2Fvsn8p7I41aOFXmlJfD6HqX3YEB88%3D'
$destination3 ="C:\temp\Carbon-1.6.0.zip"
(New-Object System.Net.WebClient).DownloadFile($BlobUri3, $destination3)
Sleep 5
Expand-Archive -Path "C:\temp\Carbon-1.6.0.zip" -DestinationPath "C:\temp\Carbon-1.6.0" -Force
Sleep 5