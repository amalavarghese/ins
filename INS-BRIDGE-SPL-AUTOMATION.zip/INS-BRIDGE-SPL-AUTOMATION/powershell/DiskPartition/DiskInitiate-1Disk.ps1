# Check if E: drive is allocated 50GB
$DriveE = Get-CimInstance -ClassName Win32_Volume -Filter "DriveLetter = 'E:'"
$DriveESizeGB = [math]::Round($DriveE.Capacity / 1GB)

if ($DriveESizeGB -eq 50) {
    Write-Output "Drive E: is already allocated 50GB. Leaving it as is."
} else {
    Write-Output "Changing Drive E: letter to X:."
    $DriveE | Set-CimInstance -Property @{DriveLetter ='X:'}
    Sleep 2
}

$disks = Get-Disk | Where partitionstyle -eq 'raw' | Sort-Object Number
$letters = 69..89 | ForEach-Object { [char]$_ }
$count = 0
$labels = "SSDv2 Logs","SSDv2 Logs"

$partitionstyle = "GPT"  # MBR or GPT
$allocationUnitSizeKB = 64  # Use it in KB
$allocationUnitSizeBytes = [uint32]($allocationUnitSizeKB * 1KB)
$FileSystemFormatType = "NTFS"

foreach ($disk in $disks) {
    $driveLetter = $letters[$count].ToString()
    
    $disk | 
    Initialize-Disk -PartitionStyle $partitionstyle -PassThru |
    New-Partition -UseMaximumSize -DriveLetter $driveLetter |
    Format-Volume -FileSystem $FileSystemFormatType -AllocationUnitSize $allocationUnitSizeBytes -NewFileSystemLabel $labels[$count] -Confirm:$false -Force
    
    $count++
}

##### End of the Script #####
