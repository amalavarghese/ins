﻿## Read CSV file

Write-Host "Reading the CSV input file."
$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName", "ResourceGroup","DiskSize"

####### Disk Partition #######
ForEach($userobjects in $userobjects){
##----------------DiskSize Initiation--------------------##
if($userobjects.DiskSize -eq '200,50'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : 2 Disk Partition Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/DiskPartition/DiskInitiate-2Disks.ps1'
        Write-Host "$vmlist : 2 Disk Partition Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : 2 Disk Partition Task End Time: $endTime"
    }
}

if($userobjects.DiskSize -eq '50'){
    $vmrg = $userobjects.ResourceGroup
    $vmsinrg = $userobjects.VMName
    
    foreach($vmlist in $vmsinrg){
        $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : 1 Disk Partition Start Time: $startTime"

        Invoke-AzVMRunCommand -ResourceGroupName $vmrg -VMName $vmlist -CommandId 'RunPowerShellScript' -ScriptPath './powershell/DiskPartition/DiskInitiate-1Disk.ps1'
        Write-Host "$vmlist : 1 Disk Partition Successfull"

        $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        Write-Host "$vmlist : 1 Disk Partition Task End Time: $endTime"
    }
}

}
##### End of the Script #####