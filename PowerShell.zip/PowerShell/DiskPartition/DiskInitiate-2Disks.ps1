# Function to change drive letter temporarily
function Change-DriveLetter {
    param (
        [string]$OldLetter,
        [string]$TempLetter
    )
    $volume = Get-Volume -DriveLetter $OldLetter
    if ($volume) {
        Set-Partition -DiskNumber $volume.DiskNumber -PartitionNumber $volume.PartitionNumber -NewDriveLetter $TempLetter
    }
}
 
# Identify the new disks by size and ensure they are uninitialized
$disk200GB = Get-Disk | Where-Object { $_.Size -ge 199GB -and $_.Size -le 201GB -and $_.PartitionStyle -eq 'RAW' }
$disk50GB = Get-Disk | Where-Object { $_.Size -ge 49GB -and $_.Size -le 51GB -and $_.PartitionStyle -eq 'RAW' }
 
# Check if the 200GB disk is found
if ($disk200GB -ne $null) {
    # Initialize the 200GB disk as GPT
    Initialize-Disk -Number $disk200GB.Number -PartitionStyle GPT
 
    # Create partition and assign drive letter E
    $partition200GB = New-Partition -DiskNumber $disk200GB.Number -UseMaximumSize -DriveLetter E
    Format-Volume -Partition $partition200GB -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SSDv2 DATA"
    # Check if the 50GB disk is also found
    if ($disk50GB -ne $null) {
        # Initialize the 50GB disk as GPT
        Initialize-Disk -Number $disk50GB.Number -PartitionStyle GPT
 
        # Create partition and assign drive letter F
        $partition50GB = New-Partition -DiskNumber $disk50GB.Number -UseMaximumSize -DriveLetter F
        Format-Volume -Partition $partition50GB -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SSDv2 Log"
    }
} elseif ($disk50GB -ne $null) {
    # Only 50GB disk is found, initialize as GPT
    Initialize-Disk -Number $disk50GB.Number -PartitionStyle GPT
 
    # Create partition and assign drive letter E
    $partition50GB = New-Partition -DiskNumber $disk50GB.Number -UseMaximumSize -DriveLetter E
    Format-Volume -Partition $partition50GB -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SSDv2 Log"
} else {
    Write-Host "No disks with the specified sizes were found."
}


#>