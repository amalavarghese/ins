param (
    [string] $domainPassword
)

Write-Host "Domain password: $domainPassword"
## Read CSV file
$userobjects = Import-CSV bridge-vm-details.csv | Select-Object "VMName","ResourceGroup","ServerType"

ForEach($userobjects in $userobjects){

    if($userobjects.ServerType -eq 'DB'){
        $vmrg = $userobjects.ResourceGroup
        $vmsinrg = $userobjects.VMName
        
        foreach($vmlist in $vmsinrg){

            $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join with SQL OU Task Start Time: $startTime"
            Write-Host "$vmlist : Domain Join with SQL OU Task Initiated"

            Invoke-AzVMRunCommand -ResourceGroupName $vmRG -Name $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'SQL-DomainJoin-Script.ps1'

            Write-Host "$vmlist : Completed Domain Join with SQL OU"
            $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join Task End Time: $endTime"
        }
    }    
    else {
        $vmrg = $userobjects.ResourceGroup
        $vmsinrg = $userobjects.VMName
        
        foreach($vmlist in $vmsinrg){

            $startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join Task with WebApp OU Start Time: $startTime"
            Write-Host "$vmlist : Domain Join Task with WebApp OU Initiated"

            Invoke-AzVMRunCommand -ResourceGroupName $vmRG -Name $vmlist -CommandId 'RunPowerShellScript' -ScriptPath 'WEB-DomainJoin-Script.ps1'

            Write-Host "$vmlist : Completed Domain Join with WebApp OU"
            $endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
            Write-Host "$vmlist : Domain Join with WebApp OU Task End Time: $endTime"
        }
            
    }
}
### End of Script