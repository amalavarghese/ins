param (
    [string] $domainPassword
)
$domainName = "insurity.cloud"
$SQLOU = "OU=SQL,OU=Bridge,OU=UAT,OU=AzureCanada,DC=insurity,DC=cloud"
$domainUsername = "insurity.cloud\svcdomainjoin"
$domPassword = ConvertTo-SecureString $domainPassword -AsPlainText -Force

$credential = New-Object System.Management.Automation.PSCredential ($domainUsername, $domainPassword)
Add-Computer -DomainName $domainName -Credential $credential -OUPath $SQLOU -Restart -Force