## Read CSV file
$vmlist = Import-CSV bridge-vm-details.csv | Select-Object "VMName","ResourceGroup","GroupName"

foreach ($vm in $vmlist){
$vmName = $vm.VMName
$vmRG = $vm.ResourceGroup
$AdGrp = $vm.GroupName

$startTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Write-Host "$vmName : Add to AD Group Task Start Time: $startTime"
Write-Host "$vmName : Adding to AD group."

Invoke-AzVMRunCommand -ResourceGroupName $vmRG -Name $vmName -CommandId 'RunPowerShellScript' -ScriptPath './powershell/Add_AD/add_ad.ps1' -Parameter @{AdGrp = $AdGrp}

Write-Host "$vmName : Completed adding to AD group."
$endTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Write-Host "$vmName : Add to AD Group Task End Time: $endTime"

}
### End of Script

