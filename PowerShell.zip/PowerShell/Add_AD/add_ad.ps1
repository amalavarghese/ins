param(
    [string] $AdGrp
)

Write-Output "Adding account to Administrators group."

Add-LocalGroupMember -Group "Administrators" -Member $AdGrp
