Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/caagents/LAPS/LAPS.x64.msi?sp=r&st=2024-06-14T08:21:05Z&se=2024-06-30T16:21:05Z&spr=https&sv=2022-11-02&sr=b&sig=5JqF0pc3HKJNDp65mk7xwvAHvrDz9csh9%2Be4If%2BkpXc%3D'

$destination = "C:\LAPS.x64.msi"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

Start-Process C:\LAPS.x64.msi -ArgumentList "/quiet /passive" -PassThru