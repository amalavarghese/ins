Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/caagents/CrowdStrike/WindowsSensor.exe?sp=r&st=2024-06-14T07:55:04Z&se=2024-06-30T15:55:04Z&spr=https&sv=2022-11-02&sr=b&sig=G3GArHfrZcoNcAB6eBCnpdB%2FYLdroqnzjutsTLK%2B7MQ%3D'

$destination ="C:\WindowsSensor.exe"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

C:\WindowsSensor.exe /install /quiet /norestart CID=02231C4853AC45A6AEA67F819EC66D5A-0E pause