Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/caagents/AppDynamicsMA/AppD-MachineAgent/dotNetAgentSetup64-24.4.0.11191.msi?sp=r&st=2024-06-14T07:52:43Z&se=2024-06-30T15:52:43Z&spr=https&sv=2022-11-02&sr=b&sig=qZIOMBO8x6Ekt%2F5UA7dzThwZctVYrkRCjvSZQhLW2PQ%3D'

$destination ="C:\dotNetAgentSetup64-24.4.0.11191.msi"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)


#Identify the location of the new MSI you want to push into the servers
$path_agent_installation = "C:\dotNetAgentSetup64-24.4.0.11191.msi"
$path_appd_configuration =  "C:\ProgramData\AppDynamics\DotNetAgent\Config\config.xml"
$controller_port = "443"
$controller_ssl_enabled = "true"
$controller_enable_tls12 = "true"
$controller_host = "insurity-test.saas.appdynamics.com"
$account_name = "insurity-test"
$account_access_key = "x121vsdjunpo"
$defaultApplicationName = "DefaultApplication"
$defaultApplicationFlag = "true"
########################################################################
#endregion
########################################################################   


# Install the MSI on the new server
msiexec /i $path_agent_installation /quiet /norestart

#wait 2 minutes before checking
Sleep 240

#AppDynamics Service name
$AppDserviceName = 'AppDynamics.Agent.Coordinator'

#Check if the new service exist and running


#Modify Default Configuration

    Write-Host "The server will stop the AppD Agent service."
    Stop-Service $AppDserviceName

    Sleep 30


    # Update AppD Machine Agent xml

        $XML_Controller_Conf_path = $path_appd_configuration

        [xml]$XmlDocument = Get-Content $XML_Controller_Conf_path

        #Default controller
        $XmlDocument.'appdynamics-agent'.controller.setattribute("enable_tls12",$controller_enable_tls12)
        $XmlDocument.'appdynamics-agent'.controller.setattribute("ssl",$controller_ssl_enabled)
        $XmlDocument.'appdynamics-agent'.controller.setattribute("port",$controller_port)
        $XmlDocument.'appdynamics-agent'.controller.host = $controller_host     
        #Default Account

        $newNode = $XmlDocument.CreateNode("element","account","")
        $newNode.setattribute("name",$account_name)
        $newNode.setattribute("password",$account_access_key)
        $XmlDocument.'appdynamics-agent'.controller.AppendChild($newNode)

  

        #Default Application
        $XmlDocument.'appdynamics-agent'.controller.application.setattribute("name",$defaultApplicationName)
        $XmlDocument.'appdynamics-agent'.controller.application.setattribute("default",$defaultApplicationFlag)

        $XmlDocument.save($XML_Controller_Conf_path)

        #fix format
        (Get-Content -Path $XML_Controller_Conf_path) -replace '" />','"/>' -replace ' "/>','"/>' | Set-Content $XML_Controller_Conf_path

    Write-Host "The server will start the AppD Agent service."
    Start-Service $AppDserviceName
