Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/caagents/AppDynamicsMA/AppD-MachineAgent/machineagent-bundle-64bit-windows.zip?sp=r&st=2024-06-14T08:21:58Z&se=2024-06-30T16:21:58Z&spr=https&sv=2022-11-02&sr=b&sig=aKqQkXyvW6GDVQV0MO6jXabMvHTmEzqoXMayeH6cJw8%3D'

$destination ="C:\machineagent-bundle-64bit-windows.zip"

(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)

Sleep 5

Expand-Archive -Path "C:\machineagent-bundle-64bit-windows.zip" -DestinationPath "C:\Temp\machineagent-bundle-64bit-windows" -Force

Sleep 5

param(
  [string]$Machine_Agent_Path,
  [string]$Environment_Stack_Name,
  [string]$Server_Type,
  [string]$controller_host,
  [string]$account_name,
  [string]$account_access_key,
  [string]$SourceFilePath_SIMAgent
)

Try
{
########################################################################
   #region Parameters
   ########################################################################
    $default_appd_machine_agent_root_path = "C:\Program Files\AppDynamics\machineagent-bundle-64bit-windows"
    $Machine_Agent_Service_Name = "Appdynamics Machine Agent"
    $SourceFilePath_SIMAgent = "C:\Temp\machineagent-bundle-64bit-windows"

    # Prod AppDynamics SaaS & Proxy Parameters

       $controller_port = "443"
       $controller_ssl_enabled = "true"
	   $controller_host = "insurity-test.saas.appdynamics.com"
	   $account_name = "insurity-test"
	   $account_access_key ="x121vsdjunpo"
	   $Environment_Stack_Name = "UAT-IDS-AZ" ## Set according to environment
       $Server_Type = "WEB"  ## Web, App, Cognos - Web
       $MachinePath_token = $Environment_Stack_Name + "|" + $Server_Type + "|" +"$Env:Computername"

   ########################################################################
   #endregion
########################################################################   

# Get Start Time
$startDTM = (Get-Date)
"The Script Started at : " + $startDTM


function Check_Service_Status
{
  param([string]$serviceName)

    If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

        If ((Get-Service $serviceName).Status) {
            $service_status = "$serviceName found and running."
        } Else {
            $service_status = "$serviceName found, but it is not running."
        }

    } Else {
        $service_status = "$serviceName not found"
    }
    return $service_status
}

function Check_Service_Exit
{
  param([string]$serviceName)

    If (Get-Service $serviceName -ErrorAction SilentlyContinue) {
         return $true
    }
    Else
    {
         return $false
    }
}

function Add_Sagar_Metic
{
  param([string]$default_appd_machine_agent_root_path)

#  AppDynamics use SIGAR metrics
   $add_SIGAR_SETTING = "-Dappdynamics.machine.agent.extensions.sim.sigarCollectorEnabled=true"

    Try
    {

# Add Proxy Setting to Java boot options
   $MachineAgentService_vmoptions_path = $default_appd_machine_agent_root_path + "\bin\MachineAgentService.vmoptions"
   $SIGAR_SETTING = $null

# Check if SIGAR value is there
   $SIGAR_SETTING = Select-String -Path $MachineAgentService_vmoptions_path -Pattern $add_SIGAR_SETTING 

   if ($SIGAR_SETTING)
   {
        return $true
   } 
   
   else 
   {   

        # Stop Machine Agent
       Stop-Service -Name "Appdynamics Machine Agent"

        # Wait 10 Seconds
       Start-Sleep -Seconds 10
 
        # Update Java content
       Add-Content -Path $MachineAgentService_vmoptions_path -Value `n$add_SIGAR_SETTING

        # Restart Services   
       Start-Service -Name "Appdynamics Machine Agent"

        # Set Service to Automatic
       set-service "Appdynamics Machine Agent" -startuptype automatic

       write-host "SIGAR VALUE is added succesfully to AppD SIM Agent configuration" -ForegroundColor DarkGreen

       return $true
   }
    }
    Catch
    {
        Write-Output $_.Exception.Message
        Write-Error 'Error Encountered when running the script' -ErrorAction Stop -Exception $_.Exception.Message
        Exit -1
    }
}



    # Check if SIM Agent is Installed
Write-Host "Step 0 : Check if server able to reach the controller ..."
    if ((Test-NetConnection $controller_host -Port $controller_port).TcpTestSucceeded) {
        Write-Host "Step 0 : The Server was able to reach $controller_host on port $controller_port Successfully." -ForegroundColor DarkGreen

    }

    else
    {
        Write-Host "Step 0 : The Server can't reach $controller_host on port $controller_port. Please Investigate on the firewall level." -ForegroundColor DarkYellow
        Exit -1
    }

    # Check if SIM Agent is Installed
Write-Host "Step 1 : Check if Sim Agent is installed..."
    if (Check_Service_Exit $Machine_Agent_Service_Name) {
        $service_output = Check_Service_Status $Machine_Agent_Service_Name
        Write-Host "Step 1 : The SIM Agent already installed on this server and windows service status is $service_output" -ForegroundColor DarkGreen
        Exit -1
    }

    else
    {
        Write-Host "Step 1 : The SIM Agent service was not found, installation process will start ..." -ForegroundColor DarkYellow

    }


# Copy SIM Agent installation
Write-Host "Step 2 : Copying Sim Agent configuration files..."
    if(Test-Path $SourceFilePath_SIMAgent)
    {
        Copy-Item -Path $SourceFilePath_SIMAgent -Destination $default_appd_machine_agent_root_path  -recurse -container -Force
        Write-Host "Step 2 : Copying Sim Agent configuration files is done to $default_appd_machine_agent_root_path." -ForegroundColor DarkGreen
    }
    else
    {
        Write-Error "Step 2 : Source Folder for SIM agent installation was not found under $($SourceFilePath_SIMAgent)"
        Exit -1
    }


# Configure SIM Agent 
Write-Host "Step 2 : Configuring Sim Agent configuration xml file..."
# Test if Machine Agent Exist with the common name
    if (Test-Path $default_appd_machine_agent_root_path)
    {
    }
    else
    {
        Write-Error "Step 2 : SIM agent root path was not found under $($default_appd_machine_agent_root_path)"
        Exit -1
    }

# Add Proxy Setting to Java boot options

    #$MachineAgentService_vmoptions_path = $default_appd_machine_agent_root_path + "\bin\MachineAgentService.vmoptions"
    #Add-Content $MachineAgentService_vmoptions_path $Proxy_Host_IP
    #Add-Content $MachineAgentService_vmoptions_path $Proxy_Host_Port

# Update AppD Machine Agent xml

   $XML_Controller_Conf_path = $default_appd_machine_agent_root_path + "\conf\controller-info.xml"

   [xml]$XmlDocument = Get-Content $XML_Controller_Conf_path

   $XmlDocument.'controller-info'.'controller-host'= $controller_host
   $XmlDocument.'controller-info'.'controller-port' = $controller_port
   $XmlDocument.'controller-info'.'controller-ssl-enabled' =$controller_ssl_enabled
   $XmlDocument.'controller-info'.'account-name'= $account_name
   $XmlDocument.'controller-info'.'account-access-key' = $account_access_key
   $XmlDocument.'controller-info'.'sim-enabled'= "true"
   $XmlDocument.'controller-info'.'machine-path'= $MachinePath_token
   $XmlDocument.'controller-info'.'dotnet-compatibility-mode'= "true"
   $XmlDocument.'controller-info'.'unique-host-id'=   $Env:Computername
   $XmlDocument.save($XML_Controller_Conf_path)

   #fix format
   (Get-Content -Path $XML_Controller_Conf_path) -replace '" />','"/>' -replace ' "/>','"/>' | Set-Content $XML_Controller_Conf_path

   Write-Host "Step 2 : Configuring Sim Agent configuration xml file is done." -ForegroundColor DarkGreen

# Install SIM Agent 
Write-Host "Step 4 : Installing Sim Agent and configuring Service..."
   cd $default_appd_machine_agent_root_path
   .\InstallService.vbs
   Start-Service -Name $Machine_Agent_Service_Name -ErrorAction SilentlyContinue

   Sleep 5

    # Check if SIM Agent is Installed
    if (Check_Service_Exit $Machine_Agent_Service_Name) {
        $service_output = Check_Service_Status $Machine_Agent_Service_Name
        Write-Host "Step 4 : The SIM Agent windows service status is $service_output" -ForegroundColor DarkGreen
    }

    else
    {
        Write-Host "Step 4 : The SIM Agent service was not found please investigate." -ForegroundColor DarkYellow
       Exit -1
    }


# Add Sagar Metric
Write-Host "Step 5 : Applying Sagar Metric best practices on the Agent configuration..."
$sagar_results = Add_Sagar_Metic -default_appd_machine_agent_root_path $default_appd_machine_agent_root_path

    # Check if SIM Agent is Installed
    if (Check_Service_Exit $Machine_Agent_Service_Name -and $sagar_results) {
        $service_output = Check_Service_Status $Machine_Agent_Service_Name
        Write-Host "Step 5 : The SIM Agent windows service status is $service_output after Sagar Metric update" -ForegroundColor DarkGreen
    }

    else
    {
        Write-Host "Step 5 : The SIM Agent service was not found or sagar metric update failed please investigate." -ForegroundColor DarkYellow
       Exit -1
    }

# Get End Time of Report Execution
$endDTM = (Get-Date)
"The Script Ended at : " + $endDTM

# Echo Time elapsed to gather stats on how long it took
"Elapsed Time of script Execution: $(($endDTM-$startDTM).totalseconds) seconds"

}
Catch
{
    Write-Output $_.Exception.Message
    Write-Error 'Error Encountered when running the script' -ErrorAction Stop -Exception $_.Exception.Message
    Exit -1
}