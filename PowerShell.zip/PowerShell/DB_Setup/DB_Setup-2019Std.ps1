Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\.NetFramework\v4.0.30319' -Name 'SchUseStrongCrypto' -Value '1' -Type DWord

#Copying "SQL 2019 Std zip File"
$BlobUri = 'https://pypzstlevel0.blob.core.windows.net/bridge-prerequisites/SQL-2019Std.zip?sp=r&st=2024-06-07T12:03:24Z&se=2024-06-28T20:03:24Z&spr=https&sv=2022-11-02&sr=b&sig=oEDtMJuokbe8yltkcy1ROnumh%2BENOx9H%2FkZA6mCd9ac%3D'
$destination = "C:\Temp\SQL-2019Std.zip"
(New-Object System.Net.WebClient).DownloadFile($BlobUri, $destination)
#Expanding
Write-Output "Copy Zip finished"
Expand-Archive -Path "C:\Temp\SQL-2019Std.zip" -DestinationPath "C:\Temp" -Force
Write-Output "UnZip finished"

#Copying "SQL 2019 kb File"
$BlobUri2 = 'https://pypzstlevel0.blob.core.windows.net/bridge-prerequisites/SQLServer2019-KB5017593-x64.exe?sp=r&st=2024-06-07T12:08:34Z&se=2024-06-28T20:08:34Z&spr=https&sv=2022-11-02&sr=b&sig=crsZch3Hsx7h2PeVADaFSTHKbF9%2BjP%2BDwNkbryD2OQI%3D'
$destination2 = "C:\Temp\SQLServer2019-KB5017593-x64.exe"
(New-Object System.Net.WebClient).DownloadFile($BlobUri2, $destination2)
Write-Output "Copy KB finished"

#Copying "SSMS File"
$BlobUri3 = 'https://pypzstlevel0.blob.core.windows.net/bridge-prerequisites/SSMS20.1-Setup-ENU.exe?sp=r&st=2024-06-07T12:11:39Z&se=2024-06-28T20:11:39Z&spr=https&sv=2022-11-02&sr=b&sig=oc7n%2FU87CHnv4EqXtgHcZcSw9qATm6dHhNyz%2FHGG3To%3D'
$destination3 = "C:\Temp\SSMS20.1-Setup-ENU.exe"
(New-Object System.Net.WebClient).DownloadFile($BlobUri3, $destination3)
Write-Output "Copy SSMS finished"

#Copying "INI File"
$BlobUri4 = 'https://pypzstlevel0.blob.core.windows.net/bridge-prerequisites/ConfigurationFile_2019_ENT_BRG-nonprod.ini?sp=r&st=2024-06-10T17:41:45Z&se=2024-06-29T01:41:45Z&spr=https&sv=2022-11-02&sr=b&sig=sQllrzpPXgrRdfAYefCDXYK9%2BQXXvIJItbJNX%2FHEgJA%3D'
$destination4 = "C:\Temp\ConfigurationFile_2019_ENT_BRG-nonprod.ini"
(New-Object System.Net.WebClient).DownloadFile($BlobUri4, $destination4)
Write-Output "Copy INI finished"


 
Write-Output "Installing with INI"
C:\Temp\SQL-2019Std\setup.exe /ConfigurationFile=C:\Temp\ConfigurationFile_2019_ENT_BRG-nonprod.ini /IAcceptSQLServerLicenseTerms /SAPWD=awW429uBcNZ7iqANs6fLJMxUu
 
Write-Output "Installing KB File"
C:\Temp\SQLServer2019-KB5017593-x64.exe /qs /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceName=MSSQLSERVER
 
Write-Output "Installing SSMS"
C:\Temp\SSMS20.1-Setup-ENU.exe /install /passive
 
Write-Output "Uninstalling Defender"
# Uninstall Windows Defender features
Uninstall-WindowsFeature -Name Windows-Defender
 
Write-Output "Installing Failover Clustering"
# Install Failover Clustering feature
Install-WindowsFeature -Name Failover-Clustering -IncludeManagementTools

################## End of Script ##################