
#!/bin/sh
######## Kubectl Install########################
echo "Start kubectl installation"
#cd /home/$1

sudo snap install kubectl --channel=1.21/stable --classic

sudo snap refresh kubectl

kubectl version
echo "End kubectl installation"
echo "\n\n"
#!/bin/sh
########Helm Installation##################
echo $@
#cd /home/$1
helm_version=3.7.0

echo "Starting Helm Installation"

echo "Downloading the $helm_version version of Helm"

wget https://get.helm.sh/helm-v$helm_version-linux-amd64.tar.gz

echo "Downloading Completed"

echo "unpack the Helm file"

tar xvf helm-v$helm_version-linux-amd64.tar.gz

echo "unpack the Helm file finished"

sudo mv linux-amd64/helm /usr/local/bin

echo "Remove the downloaded file"

rm helm-v$helm_version-linux-amd64.tar.gz

echo "Removed the downloaded file"

echo "Remove the linux-amd64 directory to clean up space"

rm -rf linux-amd64

echo "Removed the linux-amd64 directory to clean up space"

helm version

echo "End Helm Installater"

echo "\n\n"
#!/bin/sh
######## Docker Install########################
echo $@
echo "Start Docker installation"
cd /home/

sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

sudo apt-get update

sudo apt-cache policy docker-ce

sudo apt-get install -y docker-ce
cd
echo "End Docker installation"
echo "\n\n"

#!/bin/sh
######## terraform Install########################
echo $@

sudo apt-get update && sudo apt-get install -y gnupg software-properties-common curl

curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add -

sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"

sudo apt-get update && sudo apt-get install terraform

terraform -help

echo "Start terraform installation"

echo "End terraform installation"

echo "\n\n"

#!/bin/sh
########Powershell Installation###############
echo "Starting Powershell Installation"
#cd /home/$1

sudo snap install powershell --classic

sudo snap refresh powershell

echo "End Powershell Installater"
echo "\n\n"

#!/bin/sh
########.NET Core SDK Install####################
echo $@
echo "Start .NET Core SDK installation"
#cd /home/$1

sudo snap install dotnet-sdk --classic

echo "End .NET Core SDK installation"
echo "\n\n"

######## .NET Core 2.1 Runtime Install##########
echo "Start .NET Core 2.1  installation"

sudo snap install dotnet-runtime-21

echo "End .NET Core 2.1 Runtime installation"
echo "\n\n"

########  .NET Runtime 3.1 (LTS) Install#########
echo "Start .NET Runtime 3.1  installation"

sudo snap install dotnet-runtime-31

echo "End  .NET Runtime 3.1 (LTS) installation"
echo "\n\n"

#!/bin/sh
######Azure CLI installation################
echo $@
echo "Start Azure CLI installation"

sudo apt-get update
sudo  apt-get --yes install ca-certificates curl apt-transport-https lsb-release gnupg
sudo  curl -sL https://packages.microsoft.com/keys/microsoft.asc |
    gpg --dearmor |
    tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null

AZ_REPO=$(lsb_release -cs)

echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $AZ_REPO main" |
    tee /etc/apt/sources.list.d/azure-cli.list

sudo apt-get --yes update

sudo apt-get --yes install azure-cli

sudo apt install azure-cli

az --version
echo "End Azure CLI installation"
echo "\n\n"

#!/bin/sh
########Git Installation##################
echo $@
#cd /home/$1

echo "Starting Git Installation"

sudo apt-get --yes install unzip

sudo apt --yes update

sudo apt --yes install make libssl-dev libghc-zlib-dev libcurl4-gnutls-dev libexpat1-dev gettext unzip git

git --version

echo "End Git Installater"
echo "\n\n"
