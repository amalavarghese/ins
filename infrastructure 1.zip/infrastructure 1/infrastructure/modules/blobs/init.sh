export RUNNER_ALLOW_RUNASROOT="1"
mkdir actions-runner && cd actions-runner
curl -o actions-runner-linux-x64-2.288.1.tar.gz -L https://github.com/actions/runner/releases/download/v2.288.1/actions-runner-linux-x64-2.288.1.tar.gz
tar xzf ./actions-runner-linux-x64-2.288.1.tar.gz
./config.sh --url https://github.com/rahultamgadgemotif/rahultamgadgemotif --token AYAVNNZUPX5H6LUWKVUI5DLCGBFFW --runAsService  --name "runner"  --work  "folder1"  --runnergroup default  --labels "self-hosted" --replace
nohup ./run.sh > runner.log 2>&1 &

#!/bin/sh
########Helm Installation##################
#!/bin/sh
######## Docker Install########################
echo $@
echo "Start Docker installation"
cd /home/

sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -

sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

sudo apt-get update

sudo apt-cache policy docker-ce

sudo apt-get install -y docker-ce

systemctl status docker

groupadd docker
usermod -aG docker $1
#newgrp docker
#docker run hello-world

echo "End Docker installation"
echo "\n\n"