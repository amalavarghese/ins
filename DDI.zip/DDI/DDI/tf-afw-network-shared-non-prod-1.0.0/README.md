# Networking-IAC-Deployment-Template-Repo
Template repo to serve as a base for any new Networking IAC deployment pipelines/actions

<!-- BEGIN_TF_DOCS -->
### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.75.0 |
| <a name="requirement_tfe"></a> [tfe](#requirement\_tfe) | ~> 0.49.1 |

### Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_azure_firewall"></a> [azure\_firewall](#module\_azure\_firewall) | app.terraform.io/ddiworld/firewall/azurerm | 1.0.0 |
| <a name="module_azure_firewall-policy-rule-collection-group"></a> [azure\_firewall-policy-rule-collection-group](#module\_azure\_firewall-policy-rule-collection-group) | app.terraform.io/ddiworld/firewall-policy-rule-collection-group/azurerm | 1.0.0 |
| <a name="module_azure_firewall_policy"></a> [azure\_firewall\_policy](#module\_azure\_firewall\_policy) | app.terraform.io/ddiworld/firewall_policy/azurerm | 1.0.1 |
| <a name="module_ip-groups"></a> [ip-groups](#module\_ip-groups) | app.terraform.io/ddiworld/ip-groups/azurerm | 1.0.0 |
| <a name="module_monitor_diagnostic_setting"></a> [monitor\_diagnostic\_setting](#module\_monitor\_diagnostic\_setting) | app.terraform.io/ddiworld/monitor-diagnostic-setting/azurerm | 1.0.0 |

### Resources

| Name | Type |
|------|------|
| [terraform_remote_state.network_shared](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_azure_firewall_list"></a> [azure\_firewall\_list](#input\_azure\_firewall\_list) | list of azure firewall objects | `list(any)` | `[]` | no |
| <a name="input_azure_firewall_policy_list"></a> [azure\_firewall\_policy\_list](#input\_azure\_firewall\_policy\_list) | list of azure firewall policy objects | `list(any)` | `[]` | no |
| <a name="input_azure_firewall_policy_rule_collection_group_list"></a> [azure\_firewall\_policy\_rule\_collection\_group\_list](#input\_azure\_firewall\_policy\_rule\_collection\_group\_list) | list of azure firewall rule collection objects | `list(any)` | `[]` | no |
| <a name="input_default_values"></a> [default\_values](#input\_default\_values) | Provide default values for resource if not any | `any` | `{}` | no |
| <a name="input_ip_group_list"></a> [ip\_group\_list](#input\_ip\_group\_list) | list of ip group objects | `list(any)` | `[]` | no |
| <a name="input_monitor_diagnostic_setting_list"></a> [monitor\_diagnostic\_setting\_list](#input\_monitor\_diagnostic\_setting\_list) | List of monitor\_diagnostic\_setting objects | `list(any)` | `[]` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_azure_firewall_output"></a> [azure\_firewall\_output](#output\_azure\_firewall\_output) | n/a |
| <a name="output_azure_firewall_policy_output"></a> [azure\_firewall\_policy\_output](#output\_azure\_firewall\_policy\_output) | n/a |
| <a name="output_azure_firewall_policy_rule_collection_group_output"></a> [azure\_firewall\_policy\_rule\_collection\_group\_output](#output\_azure\_firewall\_policy\_rule\_collection\_group\_output) | n/a |
| <a name="output_azure_log_analytics_workspace_output"></a> [azure\_log\_analytics\_workspace\_output](#output\_azure\_log\_analytics\_workspace\_output) | n/a |
| <a name="output_ip_group_output"></a> [ip\_group\_output](#output\_ip\_group\_output) | n/a |
| <a name="output_monitor_diagnostic_setting_output"></a> [monitor\_diagnostic\_setting\_output](#output\_monitor\_diagnostic\_setting\_output) | n/a |
<!-- END_TF_DOCS -->