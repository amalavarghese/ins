# Template Repository
This repository will function as a base template to make new repositories from either manually or with automation.  
Teams, be sure to update this README!

# How to Use
You can create a new repository using this template by selecting it from the dropdown menu within the Create a Repository menu of the webUI:
![ExampleRepoCreation](https://user-images.githubusercontent.com/103216676/218492755-fba4c3bc-89f9-44a0-a6a8-10598b0415c5.png)

Please note - ProdDev team should have default write access to all repositories.

## CodeOwners file and PR
Be sure to update the CodeOwners file first after creating a new repo from this template.  The code owners file can create a seamless workflow that will issue PRs following the rules outlined in there.  Brief documentation and comments are included in the default CODEOWNERS file already present in this repository.  
![CodeOwners](https://user-images.githubusercontent.com/103216676/218494738-621edb0f-6465-49f8-a16d-a3eef8124d27.png)
