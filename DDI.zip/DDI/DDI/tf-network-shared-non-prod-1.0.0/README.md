# Networking-IAC-Deployment-Template-Repo
Template repo to serve as a base for any new Networking IAC deployment pipelines/actions

<!-- BEGIN_TF_DOCS -->
### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.75.0 |
| <a name="requirement_tfe"></a> [tfe](#requirement\_tfe) | ~> 0.49.1 |

### Providers

No providers.

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_public_ip"></a> [public\_ip](#module\_public\_ip) | app.terraform.io/ddiworld/public-ip/azurerm | 1.0.0 |
| <a name="module_resource_Group"></a> [resource\_Group](#module\_resource\_Group) | app.terraform.io/ddiworld/resource-group/azurerm | 1.0.0 |
| <a name="module_route_table"></a> [route\_table](#module\_route\_table) | app.terraform.io/ddiworld/route-table/azurerm | 1.0.0 |
| <a name="module_subnet"></a> [subnet](#module\_subnet) | app.terraform.io/ddiworld/subnet/azurerm | 1.0.0 |
| <a name="module_subnet_route_table_association"></a> [subnet\_route\_table\_association](#module\_subnet\_route\_table\_association) | app.terraform.io/ddiworld/subnet-route-table-association/azurerm | 1.0.1 |
| <a name="module_virtual_network"></a> [virtual\_network](#module\_virtual\_network) | app.terraform.io/ddiworld/virtual-network/azurerm | 1.0.0 |

### Resources

No resources.

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_public_ip_list"></a> [public\_ip\_list](#input\_public\_ip\_list) | list of public\_ip\_list objects | `list(any)` | `[]` | no |
| <a name="input_resource_group_list"></a> [resource\_group\_list](#input\_resource\_group\_list) | list of resource\_group\_list objects | `list(any)` | `[]` | no |
| <a name="input_route_table_list"></a> [route\_table\_list](#input\_route\_table\_list) | list of route table objects | `list(any)` | `[]` | no |
| <a name="input_subnet_route_table_association_list"></a> [subnet\_route\_table\_association\_list](#input\_subnet\_route\_table\_association\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_virtual_network_dns_list"></a> [virtual\_network\_dns\_list](#input\_virtual\_network\_dns\_list) | list of virtual\_network\_dns\_list objects | `list(any)` | `[]` | no |
| <a name="input_virtual_network_list"></a> [virtual\_network\_list](#input\_virtual\_network\_list) | list of virtual\_network\_list objects | `list(any)` | `[]` | no |
| <a name="input_vnet_subnet_list"></a> [vnet\_subnet\_list](#input\_vnet\_subnet\_list) | list of vnet\_subnet\_list objects | `list(any)` | `[]` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_public_ip_output"></a> [public\_ip\_output](#output\_public\_ip\_output) | n/a |
| <a name="output_resource_group_output"></a> [resource\_group\_output](#output\_resource\_group\_output) | n/a |
| <a name="output_route_table_output"></a> [route\_table\_output](#output\_route\_table\_output) | Outputs of route table objects |
| <a name="output_subnet_route_table_association_output"></a> [subnet\_route\_table\_association\_output](#output\_subnet\_route\_table\_association\_output) | n/a |
| <a name="output_virtual_network_output"></a> [virtual\_network\_output](#output\_virtual\_network\_output) | n/a |
| <a name="output_vnet_subnet_output"></a> [vnet\_subnet\_output](#output\_vnet\_subnet\_output) | n/a |
<!-- END_TF_DOCS -->