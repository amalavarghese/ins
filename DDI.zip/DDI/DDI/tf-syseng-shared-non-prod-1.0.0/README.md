# System-IAC-Deployment-Template-Repo
Template repo to serve as a base for any new System IAC Deployment repositories 

<!-- BEGIN_TF_DOCS -->
### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.75.0 |
| <a name="requirement_tfe"></a> [tfe](#requirement\_tfe) | ~> 0.49.1 |

### Providers

| Name | Version |
|------|---------|
| <a name="provider_terraform"></a> [terraform](#provider\_terraform) | n/a |

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_keyvault"></a> [keyvault](#module\_keyvault) | app.terraform.io/ddiworld/keyvault/azurerm | 1.0.5 |
| <a name="module_private_dns_zone"></a> [private\_dns\_zone](#module\_private\_dns\_zone) | app.terraform.io/ddiworld/private-dns-zone/azurerm | 1.0.0 |
| <a name="module_private_endpoint"></a> [private\_endpoint](#module\_private\_endpoint) | app.terraform.io/ddiworld/private-endpoint/azurerm | 1.0.0 |
| <a name="module_storage_account"></a> [storage\_account](#module\_storage\_account) | app.terraform.io/ddiworld/storage-account/azurerm | 1.0.0 |
| <a name="module_user_assigned_identity"></a> [user\_assigned\_identity](#module\_user\_assigned\_identity) | app.terraform.io/ddiworld/useridentity/azurerm | 1.0.0 |

### Resources

| Name | Type |
|------|------|
| [terraform_remote_state.network_shared](https://registry.terraform.io/providers/hashicorp/terraform/latest/docs/data-sources/remote_state) | data source |

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_key_vault_list"></a> [key\_vault\_list](#input\_key\_vault\_list) | list of key\_vault\_list objects | `list(any)` | `[]` | no |
| <a name="input_private_dns_zone_list"></a> [private\_dns\_zone\_list](#input\_private\_dns\_zone\_list) | list of private\_dns\_zone\_list objects | `list(any)` | `[]` | no |
| <a name="input_private_endpoint_list"></a> [private\_endpoint\_list](#input\_private\_endpoint\_list) | list of private\_endpoint\_list objects | `list(any)` | `[]` | no |
| <a name="input_storage_account_list"></a> [storage\_account\_list](#input\_storage\_account\_list) | list of windows virtual machine objects | `list(any)` | `[]` | no |
| <a name="input_user_assigned_identity_list"></a> [user\_assigned\_identity\_list](#input\_user\_assigned\_identity\_list) | list of user assigned identity objects | `list(any)` | `[]` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_key_vault_output"></a> [key\_vault\_output](#output\_key\_vault\_output) | n/a |
| <a name="output_private_dns_zone_output"></a> [private\_dns\_zone\_output](#output\_private\_dns\_zone\_output) | n/a |
| <a name="output_storage_account_output"></a> [storage\_account\_output](#output\_storage\_account\_output) | n/a |
| <a name="output_user_assigned_identity_output"></a> [user\_assigned\_identity\_output](#output\_user\_assigned\_identity\_output) | n/a |
<!-- END_TF_DOCS -->