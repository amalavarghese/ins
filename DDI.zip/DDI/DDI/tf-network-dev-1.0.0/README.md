# Networking-IAC-Deployment-Template-Repo
Template repo to serve as a base for any new Networking IAC deployment pipelines/actions

<!-- BEGIN_TF_DOCS -->
### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.75.0 |
| <a name="requirement_tfe"></a> [tfe](#requirement\_tfe) | ~> 0.49.1 |

### Providers

No providers.

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_resource_Group"></a> [resource\_Group](#module\_resource\_Group) | app.terraform.io/ddiworld/resource-group/azurerm | 1.0.0 |
| <a name="module_route_table"></a> [route\_table](#module\_route\_table) | app.terraform.io/ddiworld/route-table/azurerm | 1.0.0 |
| <a name="module_subnet_route_table_association"></a> [subnet\_route\_table\_association](#module\_subnet\_route\_table\_association) | app.terraform.io/ddiworld/subnet-route-table-association/azurerm | 1.0.1 |

### Resources

No resources.

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_resource_group_list"></a> [resource\_group\_list](#input\_resource\_group\_list) | list of resource\_group\_list objects | `list(any)` | `[]` | no |
| <a name="input_route_table_list"></a> [route\_table\_list](#input\_route\_table\_list) | list of route table objects | `list(any)` | `[]` | no |
| <a name="input_subnet_route_table_association_list"></a> [subnet\_route\_table\_association\_list](#input\_subnet\_route\_table\_association\_list) | n/a | `list(any)` | `[]` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_resource_group_output"></a> [resource\_group\_output](#output\_resource\_group\_output) | n/a |
| <a name="output_route_table_output"></a> [route\_table\_output](#output\_route\_table\_output) | Outputs of route table objects |
| <a name="output_subnet_route_table_association_output"></a> [subnet\_route\_table\_association\_output](#output\_subnet\_route\_table\_association\_output) | n/a |
<!-- END_TF_DOCS -->